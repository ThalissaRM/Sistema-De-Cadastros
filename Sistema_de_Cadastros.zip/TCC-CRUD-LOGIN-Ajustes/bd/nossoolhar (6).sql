-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 12-Jun-2023 às 04:23
-- Versão do servidor: 10.4.27-MariaDB
-- versão do PHP: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `nossoolhar`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cadusuario`
--

CREATE TABLE `cadusuario` (
  `NUMREGISTRO` varchar(6) NOT NULL,
  `NIVEL_ACESSO` int(11) NOT NULL,
  `NOME_FUNCIONARIO` varchar(40) NOT NULL,
  `EMAIL_FUNCIONARIO` varchar(35) NOT NULL,
  `SENHA` varchar(255) NOT NULL,
  `APARECER` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `cadusuario`
--

INSERT INTO `cadusuario` (`NUMREGISTRO`, `NIVEL_ACESSO`, `NOME_FUNCIONARIO`, `EMAIL_FUNCIONARIO`, `SENHA`, `APARECER`) VALUES
('000000', 1, 'Administrador', 'administrador@nossoolhar.com', '$2y$10$c.53WFg/I7w0mTHxzE4tROle.nkKlT41DpIUAHXUTfekPlabTavJy', 0),
('444444', 3, 'Taiga Kyomoto', 'taiguinha22@gmail.com', '$2y$10$eWc/y9nGLkRog13S5gzcquurkejazCNFdpa9qGh2OV1IFPwUAd8l.', 1),
('456325', 4, 'Lulu Da Silva', 'lulu@gmail.com', '$2y$10$FANPT9wphyC/6rv9nMscE.rAGOs/4SHdMosxLxu9.1rfbZJ7/nLgi', 1),
('456987', 2, 'Julia Lima', 'julia@gmail.com', '$2y$10$l6RalYv4dosfbOMwlS1YO.iQ/JgjL15VKCZoAkXjTnXY3moSlaf0.', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `informe`
--

CREATE TABLE `informe` (
  `CODINFORME` int(11) NOT NULL,
  `DATACOMPARECIMENTO` date NOT NULL,
  `HRINICIO` time NOT NULL,
  `HRTERMINO` time NOT NULL,
  `NUMREGISTROI` varchar(6) NOT NULL,
  `CODSERVICO_SECRETARIA` int(11) NOT NULL,
  `CODSITUACAO` int(11) NOT NULL,
  `CODMULHER` int(11) NOT NULL,
  `APARECER` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `informe`
--

INSERT INTO `informe` (`CODINFORME`, `DATACOMPARECIMENTO`, `HRINICIO`, `HRTERMINO`, `NUMREGISTROI`, `CODSERVICO_SECRETARIA`, `CODSITUACAO`, `CODMULHER`, `APARECER`) VALUES
(15, '2023-06-07', '20:52:00', '21:53:00', '456325', 9, 1, 11, 1),
(16, '2022-01-07', '23:09:00', '01:13:00', '456325', 9, 2, 12, 1),
(17, '2023-06-09', '09:44:00', '10:45:00', '444444', 9, 1, 12, 1),
(18, '2023-06-10', '22:10:00', '23:11:00', '444444', 9, 1, 15, 1),
(19, '2023-06-10', '23:12:00', '01:15:00', '456325', 9, 2, 15, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `localcadastro`
--

CREATE TABLE `localcadastro` (
  `CODLOCALCADASTRO` int(11) NOT NULL,
  `NOMELOCAL` varchar(15) NOT NULL,
  `APARECER` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `localcadastro`
--

INSERT INTO `localcadastro` (`CODLOCALCADASTRO`, `NOMELOCAL`, `APARECER`) VALUES
(8, 'POSTO DE SAÚDE', 1),
(9, 'DELEGACIA', 1),
(10, 'CRAS', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `mulher`
--

CREATE TABLE `mulher` (
  `CODMULHER` int(11) NOT NULL,
  `NOME` varchar(35) NOT NULL,
  `BAIRRO` varchar(30) NOT NULL,
  `EMAIL` varchar(35) NOT NULL,
  `CEL` char(17) NOT NULL,
  `TEL` char(15) NOT NULL,
  `DTNASC` date NOT NULL,
  `CODLOCALCADASTRO` int(11) NOT NULL,
  `NUMREGISTROM` char(10) NOT NULL,
  `APARECER` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `mulher`
--

INSERT INTO `mulher` (`CODMULHER`, `NOME`, `BAIRRO`, `EMAIL`, `CEL`, `TEL`, `DTNASC`, `CODLOCALCADASTRO`, `NUMREGISTROM`, `APARECER`) VALUES
(11, 'Regiane Lima Santos', 'Rua Managuá', 'regianee234@gmail.com', '(88)8888-88888', '(11)1111-1111', '2023-06-07', 8, '456987', 0),
(12, 'Liliana Oliveira', 'Rua Manágua', 'liliana@gmail.com', '(55)5555-55555', '(55)5888-8888', '2023-06-07', 8, '444444', 1),
(13, 'Bianca Aparecida', 'Rua Silveira', 'bianca@gmail.com', '(44)4444-44444', '(66)6666-6666', '2023-06-10', 8, '444444', 1),
(14, 'Tatiana Oliveira', 'Rua Manágua', 'tatati@gmail.com', '(44)4444-44444', '(44)4444-4444', '2023-06-10', 8, '444444', 1),
(15, 'Louise Lima', 'Rua Manágua', 'louise22@gmail.com', '(77)7777-77777', '(77)7777-7777', '2023-06-01', 8, '444444', 1),
(16, 'Eliene Baleeiro', 'Rua Manágua', 'eliene22@gmail.com', '(44)4444-44444', '(44)4444-4444', '2023-06-10', 8, '444444', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `necessidade`
--

CREATE TABLE `necessidade` (
  `CODNECESSIDADE` int(11) NOT NULL,
  `NECESSIDADE` varchar(30) NOT NULL,
  `APARECER` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `necessidade`
--

INSERT INTO `necessidade` (`CODNECESSIDADE`, `NECESSIDADE`, `APARECER`) VALUES
(10, 'Psicologica', 1),
(11, 'Financeira', 1),
(12, 'Juridica ', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `necessidademulher`
--

CREATE TABLE `necessidademulher` (
  `CODNECESSIDADEMULHER` int(11) NOT NULL,
  `CODMULHER_N` int(11) NOT NULL,
  `CODNECESSIDADE` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `necessidademulher`
--

INSERT INTO `necessidademulher` (`CODNECESSIDADEMULHER`, `CODMULHER_N`, `CODNECESSIDADE`) VALUES
(11, 11, 10),
(12, 12, 10),
(13, 13, 10),
(14, 14, 10),
(15, 15, 10),
(16, 16, 10);

-- --------------------------------------------------------

--
-- Estrutura da tabela `secretaria`
--

CREATE TABLE `secretaria` (
  `CODSECRETARIA` int(11) NOT NULL,
  `NOMESECRETARIA` varchar(50) NOT NULL,
  `APARECER` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `secretaria`
--

INSERT INTO `secretaria` (`CODSECRETARIA`, `NOMESECRETARIA`, `APARECER`) VALUES
(7, 'Saúde', 1),
(8, ' Secretaria da Educação e Cultura', 1),
(9, 'Diretoria de Defesa Social', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `servico`
--

CREATE TABLE `servico` (
  `CODSERVICO` int(11) NOT NULL,
  `NOMESERVICO` varchar(50) NOT NULL,
  `OBJETIVO` longtext NOT NULL,
  `APARECER` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `servico`
--

INSERT INTO `servico` (`CODSERVICO`, `NOMESERVICO`, `OBJETIVO`, `APARECER`) VALUES
(7, 'Assistencia Psicologica', 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA', 1),
(8, 'CENTRO DE ATENÇÃO Á SAÚDE DA MULHER', 'observar a mulher que sofreu violencia e que precisa de ajuda psicologica ', 1),
(9, 'Lazer', 'proporcionar momentos de lazeres para mulher ', 1),
(10, 'Acompanhamento e Segurança', 'Monitorar a mulher que esteja sendo vitima de ameaças de seu agressor', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `servico_secretaria`
--

CREATE TABLE `servico_secretaria` (
  `CODSERVICO_SECRETARIA` int(11) NOT NULL,
  `CODSERVICO` int(11) NOT NULL,
  `CODSECRETARIA_SS` int(11) NOT NULL,
  `APARECER` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `servico_secretaria`
--

INSERT INTO `servico_secretaria` (`CODSERVICO_SECRETARIA`, `CODSERVICO`, `CODSECRETARIA_SS`, `APARECER`) VALUES
(9, 7, 7, 1),
(10, 9, 8, 1),
(11, 10, 9, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `situacao`
--

CREATE TABLE `situacao` (
  `CODSITUACAO` int(11) NOT NULL,
  `TIPOSITUACAO` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `situacao`
--

INSERT INTO `situacao` (`CODSITUACAO`, `TIPOSITUACAO`) VALUES
(1, 1),
(2, 0);

-- --------------------------------------------------------

--
-- Estrutura stand-in para vista `vw_informe`
-- (Veja abaixo para a view atual)
--
CREATE TABLE `vw_informe` (
`CODINFORME` int(11)
,`DATACOMPARECIMENTO` date
,`HRINICIO` time
,`HRTERMINO` time
,`NOMESECRETARIA` varchar(50)
,`NOMESERVICO` varchar(50)
,`TIPOSITUACAO` tinyint(1)
);

-- --------------------------------------------------------

--
-- Estrutura stand-in para vista `vw_mulher`
-- (Veja abaixo para a view atual)
--
CREATE TABLE `vw_mulher` (
`CODMULHER` int(11)
,`BAIRRO` varchar(30)
,`CEL` char(17)
,`TEL` char(15)
,`DTNASC` date
,`NOMELOCAL` varchar(15)
,`NOME_FUNCIONARIO` varchar(40)
,`NECESSIDADE` varchar(30)
);

-- --------------------------------------------------------

--
-- Estrutura para vista `vw_informe`
--
DROP TABLE IF EXISTS `vw_informe`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_informe`  AS SELECT `informe`.`CODINFORME` AS `CODINFORME`, `informe`.`DATACOMPARECIMENTO` AS `DATACOMPARECIMENTO`, `informe`.`HRINICIO` AS `HRINICIO`, `informe`.`HRTERMINO` AS `HRTERMINO`, `secretaria`.`NOMESECRETARIA` AS `NOMESECRETARIA`, `servico`.`NOMESERVICO` AS `NOMESERVICO`, `situacao`.`TIPOSITUACAO` AS `TIPOSITUACAO` FROM ((((`informe` join `servico_secretaria` on(`informe`.`CODSERVICO_SECRETARIA` = `servico_secretaria`.`CODSERVICO_SECRETARIA`)) join `servico` on(`servico_secretaria`.`CODSERVICO` = `servico`.`CODSERVICO`)) join `secretaria` on(`servico_secretaria`.`CODSECRETARIA_SS` = `secretaria`.`CODSECRETARIA`)) join `situacao` on(`informe`.`CODSITUACAO` = `situacao`.`CODSITUACAO`))  ;

-- --------------------------------------------------------

--
-- Estrutura para vista `vw_mulher`
--
DROP TABLE IF EXISTS `vw_mulher`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_mulher`  AS SELECT `mulher`.`CODMULHER` AS `CODMULHER`, `mulher`.`BAIRRO` AS `BAIRRO`, `mulher`.`CEL` AS `CEL`, `mulher`.`TEL` AS `TEL`, `mulher`.`DTNASC` AS `DTNASC`, `localcadastro`.`NOMELOCAL` AS `NOMELOCAL`, `cadusuario`.`NOME_FUNCIONARIO` AS `NOME_FUNCIONARIO`, `necessidade`.`NECESSIDADE` AS `NECESSIDADE` FROM ((((`mulher` join `necessidademulher` on(`mulher`.`CODMULHER` = `necessidademulher`.`CODMULHER_N`)) join `necessidade` on(`necessidademulher`.`CODNECESSIDADE` = `necessidade`.`CODNECESSIDADE`)) join `localcadastro` on(`mulher`.`CODLOCALCADASTRO` = `localcadastro`.`CODLOCALCADASTRO`)) join `cadusuario` on(`mulher`.`NUMREGISTROM` = `cadusuario`.`NUMREGISTRO`))  ;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `cadusuario`
--
ALTER TABLE `cadusuario`
  ADD PRIMARY KEY (`NUMREGISTRO`);

--
-- Índices para tabela `informe`
--
ALTER TABLE `informe`
  ADD PRIMARY KEY (`CODINFORME`),
  ADD KEY `FK_NUMREGISTRO_I` (`NUMREGISTROI`),
  ADD KEY `FK_SERVICO_SECRETARIA` (`CODSERVICO_SECRETARIA`),
  ADD KEY `FK_CODSITUACAO` (`CODSITUACAO`),
  ADD KEY `FK_CODMULHER` (`CODMULHER`);

--
-- Índices para tabela `localcadastro`
--
ALTER TABLE `localcadastro`
  ADD PRIMARY KEY (`CODLOCALCADASTRO`);

--
-- Índices para tabela `mulher`
--
ALTER TABLE `mulher`
  ADD PRIMARY KEY (`CODMULHER`),
  ADD KEY `FK_CODLOCALCADASTRO` (`CODLOCALCADASTRO`),
  ADD KEY `FK_NUMREGISTRO_M` (`NUMREGISTROM`);

--
-- Índices para tabela `necessidade`
--
ALTER TABLE `necessidade`
  ADD PRIMARY KEY (`CODNECESSIDADE`);

--
-- Índices para tabela `necessidademulher`
--
ALTER TABLE `necessidademulher`
  ADD PRIMARY KEY (`CODNECESSIDADEMULHER`),
  ADD KEY `FK_CODMUL` (`CODMULHER_N`),
  ADD KEY `FK_CODNEC` (`CODNECESSIDADE`);

--
-- Índices para tabela `secretaria`
--
ALTER TABLE `secretaria`
  ADD PRIMARY KEY (`CODSECRETARIA`);

--
-- Índices para tabela `servico`
--
ALTER TABLE `servico`
  ADD PRIMARY KEY (`CODSERVICO`);

--
-- Índices para tabela `servico_secretaria`
--
ALTER TABLE `servico_secretaria`
  ADD PRIMARY KEY (`CODSERVICO_SECRETARIA`),
  ADD KEY `FK_CODSERVICO` (`CODSERVICO`),
  ADD KEY `FK_CODSECRETARIA` (`CODSECRETARIA_SS`);

--
-- Índices para tabela `situacao`
--
ALTER TABLE `situacao`
  ADD PRIMARY KEY (`CODSITUACAO`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `informe`
--
ALTER TABLE `informe`
  MODIFY `CODINFORME` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de tabela `localcadastro`
--
ALTER TABLE `localcadastro`
  MODIFY `CODLOCALCADASTRO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `mulher`
--
ALTER TABLE `mulher`
  MODIFY `CODMULHER` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `necessidade`
--
ALTER TABLE `necessidade`
  MODIFY `CODNECESSIDADE` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de tabela `necessidademulher`
--
ALTER TABLE `necessidademulher`
  MODIFY `CODNECESSIDADEMULHER` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `secretaria`
--
ALTER TABLE `secretaria`
  MODIFY `CODSECRETARIA` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `servico`
--
ALTER TABLE `servico`
  MODIFY `CODSERVICO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `servico_secretaria`
--
ALTER TABLE `servico_secretaria`
  MODIFY `CODSERVICO_SECRETARIA` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
