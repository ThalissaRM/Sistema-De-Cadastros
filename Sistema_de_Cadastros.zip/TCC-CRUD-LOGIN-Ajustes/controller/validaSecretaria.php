<?php
     require_once '../model/conn.php';
     $con = new Conexao("nossoolhar", "localhost", "root", "");
     $secretarias =addslashes($_POST['txtSecretaria']);
     $servicosSelecionados = ($_POST['selectServicos']); 
     
     //ARRAY PARA CADA CAMPO ATRIBUINDO "MARCADORES"
     $campos = array('txtSecretaria' => 'required | leng | texto',
     'selectServicos' => 'required',); 
     
     $countException = false;
     $regexTexto = "/^[A-Za-zÁáÂâÃãÉéÈèÊêÍíÏïÓóÔôÕõÖöÚúÇçÑñ'\s]+$/";

     //PERCORRE A ARRAY
     foreach ($campos as $field => $value) 
     {
          try 
          {
                //OS CAMPOS QUE TIVEREM "REQUIRED" EXECUTA ESSA VERIFICAÇÃO
               if (strpos($value, 'required') !== false)
               {
                     //VERIFICA SE ESTA VAZIO
                    if (empty($_POST[$field]) || !isset($_POST[$field])) 
                    {
                         throw new Exception;
                    }
               }
               if (strpos($value, 'leng') !== false) 
               {
                    //VERIFICA TAMANHO MINIMO
                    if ((strlen(trim($_POST[$field])) <= 2)) 
                    {
                         throw new Exception;
                    }
               }
               if (strpos($value, 'texto') !== false) 
               {
                    //VERIFICA SE ESTA DE ACORDO COM A REGEX
                    if (!preg_match($regexTexto, ($_POST[$field]) )) 
                    {
                         throw new Exception;
                    }
               }
          } 
         
          //CADA VEZ QUE EXISTIR UMA NOVA EXCEPTION(UM ERRO) DENTRO DO TRY, O CONTADOR MUDA DE FALSE PARA TRUE
          catch (Exception $e) 
          {
               echo $e->getMessage();
               $countException = true;
          }
     }
     //SE O CONTADOR NÃO VOLTAR COMO TRUE, CHAMA A FUNÇÃO 
     if (!$countException) 
     {
          //FUNÇÃO PARA VALIDAR SE JÁ EXISTE
          $con->validaSecretaria($secretarias, $servicosSelecionados);
     }else{
          echo "
          <script>alert('Preencha todos os campos corretamente!')</script>
          <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/cadastros.php'>
            ";
     }
?>
