<?php
     require_once '../model/conn.php';
     $con = new Conexao("nossoolhar", "localhost", "root", "");
     $txtNomeServico= addslashes ($_POST['txtNomeServico']);
     $txtObjetivo= addslashes($_POST['txtObjetivo']);

     //ARRAY PARA CADA CAMPO ATRIBUINDO "MARCADORES"
     $campos = array('txtNomeServico' => 'required | leng | texto',
     'txtObjetivo' => 'required | leng | texto',);

     $countException = false;
     $regexTexto = "/^[A-Za-zÁáÂâÃãÉéÈèÊêÍíÏïÓóÔôÕõÖöÚúÇçÑñ'\s]+$/";

     //PERCORRE A ARRAY
     foreach ($campos as $field => $value) 
     {
          try 
          {
                //PROCURA O 'REQUIRED' EM CADA ELEMENTO DA ARRAY; SE EXISTIR EXECUTA O CÓDIGO 
               if (strpos($value, 'required') !== false) 
               {
                    //VERIFICA SE ESTÁ VAZIO
                    if (empty($_POST[$field]) || !isset($_POST[$field])) 
                    {
                         //NOVA EXCEPTION
                         throw new Exception;
                    }
               }
               if (strpos($value, 'leng') !== false) 
               {
                    //VERIFICA O TAMANHO MINIMO
                    if ((strlen(trim($_POST[$field])) <= 2)) 
                    {
                         throw new Exception;
                    }
               }
               if (strpos($value, 'texto') !== false) 
               {
                    //COMPARA SE ESTA IGUAL A REGEX TEXTO 
                    if (!preg_match($regexTexto, ($_POST[$field]) )) 
                    {
                         throw new Exception;
                    }
               }
               }
               
               //CADA VEZ QUE EXISTIR UMA NOVA EXCEPTION(UM ERRO) DENTRO DO TRY, O CONTADOR MUDA DE FALSE PARA TRUE
               catch (Exception $e) 
               {
                    echo $e->getMessage();
                    $countException = true;
               }
          }
          
           //SE O CONTADOR NÃO VOLTAR COMO TRUE, CHAMA A FUNÇÃO 
          if (!$countException) 
          {
               //FUNÇÃO PARA VALIDAR SE JÁ EXISTE
               $con->validaServico($txtNomeServico,$txtObjetivo);
          }else{
               echo "
               <script>alert('Preencha todos os campos corretamente!')</script>
               <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/cadastros.php'>
                 ";
          }
?>
