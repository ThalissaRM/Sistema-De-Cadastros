<?php
    require_once '../model/conn.php';  
    $con = new Conexao("nossoolhar","localhost","root","");
    $NumRegistro=  addslashes($_POST['txtNumRegistro']); 
    $CodNivel=  addslashes($_POST['CodNivel']);
    $NomeFuncionario=  addslashes($_POST['txtNome']);
    $Email=  addslashes($_POST['txtEmail']); 
    $Senha = password_hash($_POST ['txtSenha'], PASSWORD_DEFAULT); 

    //ARRAY PARA CADA CAMPO ATRIBUINDO "MARCADORES"
    $campos = array(   
    'txtNumRegistro' => 'required | numero',  // MÍNIMO: 4| MÁXIMO: 6 | TIPO: NUMÉRICO 
    'CodNivel' => 'required ', // OBRIGATÓRIO
    'txtNome' => 'required | leng | texto',   // | MÍNIMO: 3  | FORMATO: ALFABETICO
    'txtEmail' => 'required | leng | email', // MÍNIMO: 3  | FORMATO: EMAIL
    'txtSenha' => 'required | leng | senha', // | MÍNIMO: 3 | MÁXIMO: 40 | AO MENOS: Maiusculo,minusculo,numero,caracter especial
    );
  
    //CONTADOR DE EXCESSÕES, INICIALIZA COMO FALSO
    $countException = false; 

    //REGEX PARA PADRONIZAR O QUE PODE SER DIGITADO
    $regexSenha = "/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[$*&@#])[0-9a-zA-Z$*&@#]+$/" ;
    $regexTexto = "/^[A-Za-zÁáÂâÃãÉéÈèÊêÍíÏïÓóÔôÕõÖöÚúÇçÑñ'\s]+$/" ; 
  
    //PERCORRE A ARRAY E ATRIBUI ELA PARA UMA VARIAVEL TEMPORARIA, O $VALUE REPRESENTA O ÍNDICE
    foreach ($campos as $field => $value) 
    {
        //TESTA TODOS OS ERROS COM TRY
        try 
        {
            //PROCURA O 'REQUIRED' EM CADA ELEMENTO DA ARRAY; SE EXISTIR EXECUTA O CÓDIGO 
            if (strpos($value, 'required') !== false) 
            {
                //VERIFICA SE ESTÁ VAZIO
                if (empty(trim($_POST[$field])) || !isset($_POST[$field]))
                {
                    //NOVA EXCEPTION
                    throw new Exception;
                }   
            }
            if (strpos($value, 'email') !== false)
            {
                //VERIFICA SE O EMAIL É UM EMAIL COM O FILTRO DO PHP
                if( !filter_var ($_POST[$field], FILTER_VALIDATE_EMAIL))
                {
                    //NOVA EXCEPTION
                    throw new Exception;
                }
            }
            if (strpos($value, 'leng') !== false) 
            {
                //VERIFICA O TAMANHO MINIMO
                if ((strlen(trim($_POST[$field])) <= 2)) 
                {
                    //NOVA EXCEPTION
                    throw new Exception;
                }   
            }       
            if (strpos($value, 'numero') !== false) 
            {
                //VERIFICA O TAMANHO MINIMO E MAXIMO DO NUMERO DE REGISTRO
                if ((strlen(trim($_POST[$field])) <= 3) || (strlen(trim($_POST[$field])) >= 7)) 
                {
                    //NOVA EXCEPTION
                    throw new Exception;  
                }
            }      
            if(strpos($value, 'numero') !== false)
            { 
                //VERIFICA SE O NUMERO É UM NUMERO MESMO
                if(!is_numeric($_POST[$field]))
                {
                    //NOVA EXCEPTION
                    throw new Exception; 
                }
            }
            if(strpos($value, 'senha'))
            {
                //COMPARA SE ESTA IGUAL A REGEX SENHA
                if (!preg_match($regexSenha, ($_POST[$field]))) 
                {
                    //NOVA EXCEPTION
                    throw new Exception;   
                }
            }      
            if(strpos($value, 'texto'))
            {
                //COMPARA SE ESTA IGUAL A REGEX TEXTO 
                if (!preg_match($regexTexto, ($_POST[$field]) )) 
                {
                    //NOVA EXCEPTION
                    throw new Exception; 
                }
            }      
        } 

        //CADA VEZ QUE EXISTIR UMA NOVA EXCEPTION(UM ERRO) DENTRO DO TRY, O CONTADOR MUDA DE FALSE PARA TRUE
        catch (Exception $e) 
        {
            echo $e->getMessage();
            $countException = true; 
        }
    }

    //SE O CONTADOR NÃO VOLTAR COMO TRUE, CHAMA A FUNÇÃO 
    if(!$countException)
    {    
        //FUNÇÃO PARA VALIDAR SE JÁ EXISTE
        $con->valida($NumRegistro,$CodNivel,$NomeFuncionario,$Email,$Senha);  
    }else{
        echo "
        <script>alert('Preencha todos os campos corretamente!')</script>
        <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/cadastraFuncionario.php'>
          ";

    }
?>




