<?php
     require_once '../model/conn.php';
     $con = new Conexao("nossoolhar", "localhost", "root", "");

     $dtcomparecimento = addslashes($_POST['dtComparecimento']);
     $hrinicio =  addslashes($_POST['tmHoraInicio']);
     $hrtermino =  addslashes($_POST['tmHoraTermino']);
     $selfuncionario = $_POST['selectFuncionario'];
     $selservicosecretaria = $_POST['selectSecretaria_Servico'];
     $selmulher = $_POST['selectMulher'];
     $selsituacao = $_POST['selectSituacao'];

     //ARRAY PARA CADA CAMPO ATRIBUINDO "MARCADORES"
     $campos = array('dtComparecimento' => ' | required ',
     'tmHoraInicio' => 'required',
     'tmHoraTermino' => 'required',
     'selectFuncionario' => 'required',
     'selectSecretaria_Servico' => 'required',
     'selectMulher' => 'required',
     'selectSituacao' => 'required',
     );

     //CONTADOR DE EXCESSÕES
     $countException = false;

    //REGEX PARA PADRONIZAR O QUE PODE SER DIGITADO     
     $regexTexto = "/^[A-Za-zÁáÂâÃãÉéÈèÊêÍíÏïÓóÔôÕõÖöÚúÇçÑñ'\s]+$/";
     
     //PERCORRE A ARRAY E ATRIBUI ELA PARA UMA VARIAVEL TEMPORARIA, O $VALUE REPRESENTA O ÍNDICE
     foreach ($campos as $field => $value) 
          {
               //TESTA TODOS OS ERROS COM TRY     
               try {
                    //PROCURA O 'REQUIRED' EM CADA ELEMENTO DA ARRAY; SE EXISTIR EXECUTA O CÓDIGO 
                    if (strpos($value, 'required') !== false) {
                         //VERIFICA SE ESTÁ VAZIO
                         if (empty($_POST[$field]) || !isset($_POST[$field])) 
                         {
                               //NOVA EXCEPTION
                              throw new Exception;
                         }
                    }
               }
                //CADA VEZ QUE EXISTIR UMA NOVA EXCEPTION(UM ERRO) DENTRO DO TRY, O CONTADOR MUDA DE FALSE PARA TRUE
               catch (Exception $e) 
               {
                    echo $e->getMessage();
                    $countException = true;
               }
          }
     //SE O CONTADOR NÃO VOLTAR COMO TRUE, CHAMA A FUNÇÃO 
     if (!$countException) 
     {
          //FUNÇÃO PARA VALIDAR SE JÁ EXISTE
          $con->insereInforme( $dtcomparecimento,$hrinicio,$hrtermino,$selfuncionario,$selservicosecretaria,$selsituacao,$selmulher);
     }else{
          echo "
          <script>alert('Preencha todos os campos corretamente!')</script>
          <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/cadastros.php'>
            ";
     }
?>
