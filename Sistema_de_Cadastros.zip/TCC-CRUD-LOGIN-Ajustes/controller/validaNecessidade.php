<?php
     require_once '../model/conn.php';
     $con = new Conexao("nossoolhar", "localhost", "root", "");
     $txtNecessidade =  addslashes ($_POST['txtNecessidade']);

     //ARRAY PARA CADA CAMPO ATRIBUINDO "MARCADORES"
     $campos = array('txtNecessidade' => 'required | leng | texto');

     
     $countException = false;
     $regexTexto = "/^[A-Za-zÁáÂâÃãÉéÈèÊêÍíÏïÓóÔôÕõÖöÚúÇçÑñ'\s]+$/";

     //PERCORRE A ARRAY 
     foreach ($campos as $field => $value) 
     {
          try {
               //OS CAMPOS QUE TIVEREM "REQUIRED" EXECUTA ESSA VERIFICAÇÃO
               if (strpos($value, 'required') !== false) 
               {
                    //VERIFICA SE ESTA VAZIO
                    if (empty(trim($_POST[$field])) || !isset($_POST[$field])) 
                    {
                         throw new Exception;
                    }
               }
               if (strpos($value, 'leng') !== false) 
               {
                    //VERIFICA O TAMANHO MINIMO
                    if ((strlen(trim($_POST[$field])) <= 2)) 
                    {
                         throw new Exception;
                    }
               }
               if (strpos($value, 'texto') !== false) 
               {
                    //VERIFICA SE ESTA DE ACORDO COM A REGEX
                    if (!preg_match($regexTexto, ($_POST[$field]) )) 
                    {
                         throw new Exception;
                    }
               }
          }
          
          //CADA VEZ QUE EXISTIR UMA NOVA EXCEPTION(UM ERRO) DENTRO DO TRY, O CONTADOR MUDA DE FALSE PARA TRUE
          catch (Exception $e) 
          {
               echo $e->getMessage();
               $countException = true;
          }
     }

     //SE O CONTADOR NÃO VOLTAR COMO TRUE, CHAMA A FUNÇÃO 
     if (!$countException) 
     {
           //FUNÇÃO PARA VALIDAR SE JÁ EXISTE
          $con->validaNecessidade($txtNecessidade);
     }else{
          echo "
          <script>alert('Preencha todos os campos corretamente!')</script>
          <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/cadastros.php'>
            ";
     }
?>
