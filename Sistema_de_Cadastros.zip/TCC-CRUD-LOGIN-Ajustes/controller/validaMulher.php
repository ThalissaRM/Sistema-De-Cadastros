<?php
    require_once '../model/conn.php';  
    $con = new Conexao("nossoolhar","localhost","root",""); 
    $nomeMulher= addslashes($_POST['txtNomeMulher']);
    $bairro= addslashes($_POST['txtBairro']);
    $emailMulher= addslashes($_POST['txtEmailMulher']);
    $celular= addslashes($_POST['txtCelular']);
    $telefone= addslashes($_POST['txtTelefone']);
    $dataNasc= addslashes($_POST['data']);
    $local= ($_POST ['selectLocal']);
    $funcionario= ($_POST ['selectFuncionario']);
    $necessidadesSelecionadas = ($_POST['necessidades']); 

    //CONTADOR DE EXCESSÕES, INICIA COMO FALSO
    $countException = false;

    //REGEX PARA SERVIR DE PARÂMETRO E PADRONIZAR OS CAMPOS
    $regexTexto = "/^[A-Za-zÁáÂâÃãÉéÈèÊêÍíÏïÓóÔôÕõÖöÚúÇçÑñ'\s]+$/" ; //REGEX LETRAS MAIUSCULAS,MINUSCULAS E ACENTUADAS
    $regexNumero ='/^\(\d{2}\)\d{4}-\d{4,5}$/';//REGEX PADRÃO:
    // "/^\([1-9]{2}\)[1-9]{4}-[1-9]{4,5}$/" 

    //ARRAY PARA CADA CAMPO ATRIBUINDO "MARCADORES"
    $campos = array(
        'txtNomeMulher' => 'required | leng | texto', // min 4 max 6 só texto
        'txtBairro' => 'required | leng | texto',
        'txtEmailMulher' => 'required |leng | email', //
        'txtCelular' => 'required | numero', // min  8 max 40 só letra
        'txtTelefone' => 'required | numero', //campo telefone 12 ou 11 
        'data' => 'required | lengdata', // numero e tamanho min e max 
        'selectLocal' => 'required ', //obrigatorio
        'selectFuncionario' => ' required', //obrigatorio  
        'necessidades' => 'required ', //minimo um 
    );

    //PERCORRE A ARRAY E ATRIBUI ELA PARA UMA VARIAVEL TEMPORARIA, O $VALUE REPRESENTA O ÍNDICE
    foreach ($campos as $field => $value) 
        {
            //TESTA TODOS OS ERROS COM TRY
            try 
            {
                // PROCURA O 'REQUIRED' EM CADA ELEMENTO DA ARRAY; SE EXISTIR EXECUTA O CÓDIGO 
                if (strpos($value, 'required') !== false) 
                {
                      //VERIFICA SE ESTÁ VAZIO
                    if(empty($_POST[$field]) || !isset($_POST[$field]))
                        {
                            //NOVA EXCEPTION
                            throw new Exception;
                        }
                }

                if (strpos($value, 'email') !== false)
                {
                    //VERIFICA SE O EMAIL É UM EMAIL COM O FILTRO DO PHP
                    if( !filter_var ($_POST[$field], FILTER_VALIDATE_EMAIL))
                        {
                            //NOVA EXCEPTION
                            throw new Exception;
                        }
                }
                if (strpos($value, 'leng') !== false) 
                    {
                    //VERIFICA TAMANHO MINIMO
                    if ((strlen(trim($_POST[$field])) <= 2)) 
                        {
                            throw new Exception;  
                        }   
                    }       
                if (strpos($value, 'numero') !== false) 
                {
                    //VERIFICA O TAMANHO MINIMO E MAXIMO DO NUMERO DE CELULAR E TELEFONE
                    if ((strlen(trim($_POST[$field])) <= 12) || (strlen(trim($_POST[$field])) >= 17)) 
                        {
                            throw new Exception; 
                        }
                        
                }      
                if(strpos($value, 'numero') !== false)
                {
                    ///VERIFICA SE O NUMERO TA DE ACORDO COM A REGEX
                    if(!preg_match($regexNumero, ($_POST[$field]) ))
                    {
                        throw new Exception;
                    }
                }
                if(strpos($value, 'texto'))
                {
                    //VERIFICA SE O TEXTO TA DE ACORDO COM A REGEX
                    if (!preg_match($regexTexto, ($_POST[$field]) )) 
                    {
                        throw new Exception;
                    }
                } 
            } 
            catch (Exception $e) 
            {
                echo $e->getMessage();
                $countException = true; 
            }
        }
         //SE O CONTADOR NÃO VOLTAR COMO TRUE, CHAMA A FUNÇÃO 
        if(!$countException)
        {  
             //FUNÇÃO PARA VALIDAR SE JÁ EXISTE
            $con->validaMulher($nomeMulher,$bairro,$emailMulher,$celular,
            $telefone,$dataNasc,$local,$funcionario,$necessidadesSelecionadas);
        }
        else{
            echo "
            <script>alert('Preencha todos os campos corretamente!')</script>
            <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/cadastros.php'>
              ";
        }

?>

