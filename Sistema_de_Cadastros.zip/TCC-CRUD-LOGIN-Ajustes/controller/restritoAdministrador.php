<?php

session_start();

if (!isset($_SESSION['idAcesso']))
{
    header('location: ../index.html');
    exit;
}

else {
    header('location: ../view/cadastros.php');
}

?>