<?php
session_start();
unset($_SESSION['idAcesso']);
header("location:../view/index.html");
?>