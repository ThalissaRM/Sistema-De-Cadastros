<?php

    require_once '../model/conn.php';
    $con = new Conexao("nossoolhar", "localhost", "root", "");
    include ('../view/index.html');
    if(isset($_POST['txtLogin']))
    {
        $email = addslashes($_POST['txtLogin']);
        $senha = addslashes($_POST['txtSenha']);
        if ($con->Login($email, $senha)) 
        {
            $verificar = $con->query("SELECT NIVEL_ACESSO, EMAIL_FUNCIONARIO, SENHA FROM CADUSUARIO");    
            while ($linha = $verificar->fetch(PDO::FETCH_ASSOC)) 
            {
                if ($linha['EMAIL_FUNCIONARIO'] == $email)
                {
                    $nivel= $linha['NIVEL_ACESSO'];
                    switch ($nivel) {
                    case'1': 
                    header("location: restritoAdministrador.php");
                    break;
                    case'2':
                    header("location: restritoModerador.php");
                    break;
                    case'3':
                    header("location: restritoFuncionario.php");
                    break;
                    case'4':
                    header("location: restritoServico.php");
                    break; 
                    }
                }
            }
        }
   }
?>