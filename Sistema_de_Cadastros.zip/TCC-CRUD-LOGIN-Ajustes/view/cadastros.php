<?php
    session_start();
    if(empty($_SESSION['idAcessoUsuario']) || ($_SESSION['idAcessoUsuario'] != '1' && $_SESSION['idAcessoUsuario'] != '2')){
        session_destroy();
        header('Location: ../view/index.html');
        exit();
    }
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <!-- Adicionei pra aparecer a select la-->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet"/>
    <link rel="shortcut icon" href="../view/images/logo_franco.jpg" type="image/jpg"> 
    <link rel="stylesheet" href="../view/css/reset.css">
    <link rel="stylesheet" href="../view/css/style.css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    <script defer src="../view/javascript/scripts.js"></script>
    <script defer src="../view/javascript/validates.js"></script>
    <script src="../view/javascript/navbar.js"></script>
    <script src="https://kit.fontawesome.com/0e0aebece5.js" crossorigin="anonymous"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nosso Olhar | Cadastros</title>
</head>
<body class="register-page">
    <div class="overlay">
    </div>
    <div class="input-return" onclick="returnPage()">
        <i class="fa-solid fa-xmark"></i>
        <input id="input-set-return" onclick="returnPage()" type="submit" value="">
    </div>
    <?php
        include ('../view/header.php');
    ?>
    <main class="register-page-return">
        <div class="container-1">
            <div class="forms-space">
                <section class="register-new-woman">
                    <div class="link-register-new-woman">
                        <div id="image-woman-01">
                            <img src="../view/images/undraw_subscribe_vspl.svg" alt="">
                        </div>
                        <div id="form-register">
                            <input onclick="EnableForm()" id="open-form" type="submit" value="novo cadastro">
                        </div>
                    </div>
                </section>
                <section class="other-registers">
                    <div class="other-register-space">
                        <div id="card-register" class="local-register">
                            <div class="image-register-01">
                                <img src="../view/icons/location-dot-solid.svg" alt="Local">
                            </div>
                            <div class="input-register-01">
                                <input id="local-register" type="submit" value="cadastrar local">
                            </div>                            
                        </div>
                        <div id="card-register" class="inf-register">
                            <div class="image-register-01">
                                <img src="../view/icons/calendar-check-solid.svg" alt="">
                            </div>
                            <div class="input-register-01">
                                <input id="presence-register" type="submit" value="registrar presença">
                            </div>                            
                        </div>
                        <div id="card-register" class="needs-register">
                            <div class="image-register-01">
                                <img src="../view/icons/hand-holding-heart-solid.svg" alt="">
                            </div>
                            <div class="input-register-01">
                                <input id="need-register" type="submit" value="nova necessidade">
                            </div>
                        </div>
                        <div id="card-register" class="work-register">
                            <div class="image-register-01">
                                <img src="../view/icons/briefcase-solid.svg" alt="Trabalho">
                            </div>
                            <div class="input-register-01">
                                <input id="work-register" type="submit" value="cadastrar serviço">
                            </div>
                        </div>
                        <div id="card-register" class="secretary-register">
                            <div class="image-register-01">
                                <img src="../view/icons/building-solid.svg" alt="Secretaria">
                            </div>
                            <div class="input-register-01">
                                <input id="secretary-register" type="submit" value="nova secretaria">
                            </div>
                        </div>    
                        <?php
                                if($_SESSION['idAcessoUsuario'] == 1) {
                                    echo "
                                    <div id='card-register' class='user-register'>
                                    <div class='image-register-01'>
                                        <img src='../view/icons/user-plus-solid.svg' alt='Usuário'>
                                    </div>
                                    
                                    <div class='input-register-01'>
                                        <form method='POST' action='../view/cadastraFuncionario.php'>
                                            <input type='submit' value='novo funcionário'>
                                        </form>
                                    </div>
                                </div>
                                    ";
                                }
                            ?>
                    </div>
                </section>
            </div>
        </div>
        <div class="cad-local-valid">
            <form method="POST" action="../controller/validaLocal.php">
                <div id="cad-local-valid" class="title-cad-local">
                    <span>CADASTRAR NOVO LOCAL</span>
                </div>
                <div id="cad-local-valid" class="input-cad-local">
                    <input type="text" name="txtLocal" placeholder="Informe o nome da unidade" required="required" minlength="3">
                </div>
                <div id="cad-local-valid" class="input-cad-local">
                    <input type="submit" value="cadastrar">
                </div>                
            </form>
        </div>
        <div class="cad-presence">
            <form method="POST" action="../controller/validaInforme.php">
                <div class="box-cad-presence">
                    <span>DATA DO COMPARECIMENTO</span>
                </div>
                <div class="box-cad-presence">
                    <input type="date" name="dtComparecimento" required>
                </div>
                <div class="box-cad-presence">
                    <span>HORA DE INÍCIO</span>
                </div>
                <div class="box-cad-presence">
                    <input type="time" name="tmHoraInicio" required>
                </div>
                <div class="box-cad-presence">
                    <span>HORA DE TÉRMINO</span>
                </div>
                <div class="box-cad-presence">
                    <input type="time" name="tmHoraTermino" required>
                </div>
                <div class="box-cad-presence">
                    <select name="selectFuncionario" required>
                        <option value="">Selecione o funcionário responsável pelo atendimento</option>
                        <?php
                            require_once '../model/conn.php';  
                            $con = new Conexao("nossoolhar","localhost","root",""); 
                            $select = "SELECT * FROM CADUSUARIO  WHERE APARECER LIKE '1' AND NUMREGISTRO ='". $_SESSION['idAcesso']."'";
                            $param = $con->query($select);
                            while ($select = $param->fetch(PDO::FETCH_ASSOC)){
                                echo '<option value="'.$select["NUMREGISTRO"]. '">';
                                echo $select ["NOME_FUNCIONARIO"];
                                echo '</label><br><br>';
                            }                        
                        ?>
                    </select>
                </div>
                <div class="box-cad-presence">
                    <select name="selectMulher" required>
                        <option value="">Selecione a mulher</option>
                        <?php
                            require_once '../model/conn.php';  
                            $con = new Conexao("nossoolhar","localhost","root",""); 
                            $select = "SELECT * FROM MULHER  WHERE APARECER LIKE '1'";
                            $param = $con->query($select);
                            while ($select = $param->fetch(PDO::FETCH_ASSOC)){
                                echo '<option value="'.$select["CODMULHER"]. '">';
                                echo $select ["NOME"];
                                echo '</label><br><br>';
                            }
                        ?>
                    </select>
                </div>
                <div class="box-cad-presence">
                    <select name="selectSituacao" required>
                        <option value="">Compareceu ao serviço?</option>
                        <?php
                        require_once '../model/conn.php';  
                        $con = new Conexao("nossoolhar","localhost","root",""); 
                        $select = "SELECT * FROM SITUACAO";
                        $param = $con->query($select);
                        while ($select = $param->fetch(PDO::FETCH_ASSOC))
                        {
                        echo '<option value="'.$select["CODSITUACAO"].'"';
                        if($select['TIPOSITUACAO'] == 0){
                            echo ">Não";
                        }
                        else{
                            echo ">Sim";
                        }
                            echo "</option>";
                    }
                ?>
                    </select>
                </div>
                <div class="box-cad-presence">
                    <select name="selectSecretaria_Servico" required>
                        <option value="">Selecione a secretaria e o serviço associado</option>
                        <?php
                            require_once '../model/conn.php';  
                            $con = new Conexao("nossoolhar","localhost","root",""); 
                            $select = "SELECT CODSERVICO_SECRETARIA, NOMESECRETARIA, NOMESERVICO FROM SERVICO_SECRETARIA INNER JOIN SERVICO ON 
                            SERVICO_SECRETARIA.CODSERVICO = SERVICO.CODSERVICO INNER JOIN SECRETARIA ON SERVICO_SECRETARIA.CODSECRETARIA_SS = SECRETARIA.CODSECRETARIA 
                            WHERE SECRETARIA.APARECER LIKE '1' AND  SERVICO.APARECER LIKE '1'";
                            $param = $con->query($select);
                            while($select = $param->fetch(PDO::FETCH_ASSOC)){
                                echo '<option value="'.$select["CODSERVICO_SECRETARIA"]. '">';
                                echo $select ["NOMESECRETARIA"]; 
                                echo " -";
                                echo $select ["NOMESERVICO"];
                                echo '</option><br><br>';
                            }
                        ?>
                    </select>
                            
                </div>
                <div class="box-cad-presence">
                    <input type="submit" value="registrar">
                </div>
            </form>
        </div>
        <div class="cad-needs">
            <form method="POST" action="../controller/validaNecessidade.php">
                <div id="title-cad-needs" class="box-cad-needs">
                    <span>CADASTRAR NOVA NECESSIDADE</span>
                </div>
                <div id="input-cad-needs" class="box-cad-needs">
                    <input type="text" name="txtNecessidade" placeholder="Informe a nova necessidade" minlength="3" required="required">
                </div>
                <div id="input-cad-needs" class="box-cad-needs">
                    <input type="submit" value="cadastrar">
                </div>                            
            </form>
        </div>
        <div class="cad-work">
            <form method="POST" action="../controller/validaServico.php">
                <div id="title-cad-secretary" class="box-cad-work">
                    <span>CADASTRAR NOVO SERVIÇO</span>
                </div>
                <div id="input-cad-work" class="box-cad-work">
                    <input type="text" name="txtNomeServico" placeholder="Informe o novo serviço" minlength="3" required="required">
                </div>
                <div id="input-cad-work" class="box-cad-work">
                    <textarea name="txtObjetivo"  minlength="3" required="required" placeholder="Informe o objetivo do serviço cadastrado"></textarea>
                </div>
                <div id="input-cad-work" class="box-cad-work">
                    <input type="submit" value="cadastrar">
                </div>                            
            </form>
        </div>
        <div class="cad-secretary">
            <form method="POST" action="../controller/validaSecretaria.php">
                <div id="title-cad-secretary" class="box-cad-secretary">
                    <span>CADASTRAR NOVA SECRETARIA</span>
                </div>
                <div id="input-cad-secretary" class="box-cad-secretary">
                    <span id="title-cad-secretary">INFORME A NOVA SECRETARIA</span>
                    <input type="text" name="txtSecretaria" required="required" minlength="3">
                </div>
                <div id="input-cad-secretary" class="box-cad-secretary">
                    <label for="idSelect2">
                    </label>
                    <span id="title-cad-secretary">SELECIONAR SERVIÇOS</span>
                        <select id="select-main" name="selectServicos[]" class="js-example-basic-multiple" multiple="multiple" required>
                            <?php
                                require_once '../model/conn.php';  
                                $con = new Conexao("nossoolhar","localhost","root",""); 
                                $select = "SELECT * FROM SERVICO WHERE APARECER LIKE '1'";
                                $param = $con->query($select);
                                while ($select = $param->fetch(PDO::FETCH_ASSOC)){
                                echo '<option value="'.$select["CODSERVICO"]. '">';           
                                    echo $select ["NOMESERVICO"];        
                                }    
                            ?>
                         </select>
                </div>
                <div id="input-cad-secretary" class="box-cad-secretary">
                    <input type="submit" value="cadastrar">
                </div>                       
            </form>
        </div>        
        <div class="cad-woman">
                <form method="POST" action="../controller/validaMulher.php">
                    <div class="form-1" id="form-1">
                        <h3>INFORMAÇÕES PRINCIPAIS</h3>
                        <div class="box-form">
                            <span>NOME COMPLETO</span>
                            <input type="text" name="txtNomeMulher">
                        </div>
                        <div class="box-form">
                            <span>DATA DE NASCIMENTO</span>
                            <input type="date" name="data">
                        </div>
                        <div class="box-form">
                            <span>ENDEREÇO</span>
                            <input type="text" name="txtBairro">
                        </div>
                        <div class="btn-box next">
                            <input type="button" value="Próximo"  id="Next-1">
                        </div>
                    </div> 
                    <div class="form-2" id="form-2">
                        <h3>CONTATO</h3>
                        <div class="box-form">
                            <span>E-MAIL</span>
                            <input type="email" name="txtEmailMulher">
                        </div>
                        <div class="box-form">
                            <span>CELULAR</span>
                            <input required="required" id="celular" type="tel" name="txtCelular" placeholder="(DDD) 9 9999-9999" >
                        </div>
                        <div class="box-form">
                            <span>TELEFONE</span>
                            <input required="required" id="telefone" type="text" name="txtTelefone" placeholder="(DDD) 4444-4444">
                        </div>
                        <div class="btn-box next">
                            <input type="button" value="Próximo" id="Next-2">
                        </div>
                        <div class="btn-box prev">
                            <input type="button" value="Voltar" id="Prev-1">
                        </div>
                    </div> 
                    <div class="form-3" id="form-3">
                        <h3>FINALIZAÇÃO DE CADASTRO</h3>
                        <div class="box-form">
                            <span>LOCAL</span>
                            <select name="selectLocal">
                            <?php
                                require_once '../model/conn.php';  
                                $con = new Conexao("nossoolhar","localhost","root",""); 
                                $select = "SELECT * FROM LOCALCADASTRO WHERE APARECER LIKE '1'";
                                $param = $con->query($select);
                                while ($select = $param->fetch(PDO::FETCH_ASSOC)){
                                echo '<option value="'.$select["CODLOCALCADASTRO"]. '">';           
                                    echo $select ["NOMELOCAL"];        
                                }    
                            ?>
                            </select>
                        </div>
                        <div class="box-form">
                            <span>FUNCIONÁRIO</span>
                            <select name="selectFuncionario">
                            <?php
                                require_once '../model/conn.php';  
                                $con = new Conexao("nossoolhar","localhost","root",""); 
                                $select = "SELECT * FROM CADUSUARIO WHERE APARECER LIKE '1' AND NUMREGISTRO ='". $_SESSION['idAcesso']."'";
                                $param = $con->query($select);
                                while ($select = $param->fetch(PDO::FETCH_ASSOC)){
                                    echo '<option value="'.$select["NUMREGISTRO"]. '">';
                                    echo $select ["NOME_FUNCIONARIO"];
                                }
                            ?>
                            </select>
                        </div>
                        <div class="box-form checkbox-items">
                            <span>NECESSIDADES</span>
                            <input id="select-checkbox" type="button" value="Clique para selecionar...">
                        </div>
                        <div class="btn-box prev">
                            <input type="button" value="Voltar" id="Prev-2">
                        </div>
                        <div class="btn-box next">
                            <input type="submit" value="Cadastrar">
                        </div>
                    </div>
                    <div class="form-4">
                        <h3>SELECIONAR NECESSIDADES</h3>
                        <div class="box-form">
                            <?php
                                require_once '../model/conn.php';
                                $con = new Conexao("nossoolhar","localhost","root",""); 
                                $checked = "SELECT * FROM necessidade  WHERE APARECER LIKE '1'";
                                $param = $con->query($checked);
                                while ($result = $param->fetch(PDO::FETCH_ASSOC)) {
                                    echo '<input class="checkbox-items" type="checkbox" name="necessidades[]" value="' .$result["CODNECESSIDADE"]. '">';
                                    echo $result ["NECESSIDADE"];
                                    echo '<p>';
                                }
                            ?>
                        </div>
                        <div class="return-button">
                            <i class="fa-solid fa-arrow-left"></i>
                        </div>
                    </div>
                </form>
            <div class="progress-bar">
                <div class="step actived" id="step-1"><span>1</span></div>
                <div class="step" id="step-2"><span>2</span></div>
                <div class="step" id="step-3"><span>3</span></div>                    
            </div>
    </main>

   
    <!-- <script src="https://code.jquery.com/jquery-3.7.0.min.js"  -->
    <!-- integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>$(document).ready(function() {
    $('.js-example-basic-multiple').select2();
    });
    </script>

<script src="javascript/lgpd.js">


</script>

</body>
</html>