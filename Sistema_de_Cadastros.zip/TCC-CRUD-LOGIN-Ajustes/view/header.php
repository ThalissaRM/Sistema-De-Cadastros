<nav>
        <div class="position-logo">
            <?php
                if($_SESSION['idAcessoUsuario']==1 || $_SESSION['idAcessoUsuario']==2)
                {
                    echo "<a href='../view/cadastros.php'><img src='../view/images/logo_franco.png' alt='Logo Franco da Rocha'></a>";
                }
                else if($_SESSION['idAcessoUsuario']== 3)
                {
                    echo "<a href='../view/cadastraMulher.php'><img src='../view/images/logo_franco.png' alt='Logo Franco da Rocha'></a>";
                }
                else{
                    echo "<a href='../view/registraPresenca.php'><img src='../view/images/logo_franco.png' alt='Logo Franco da Rocha'></a>";
                }
            ?>
        </div>
        <div class="options-nav-bar">
            <div class="menu-item">
                <div class="icon-for-open-menu">
                    <i onclick="ShowHide()" class="fa-solid fa-bars"></i>
                </div>
            </div>
            <div class="options-nav-bar-1">
                <ul>  <!--id="options-ul" -->
                    <li>
                        <?php
                            if($_SESSION['idAcessoUsuario']==1 || $_SESSION['idAcessoUsuario']==2)
                            {
                                echo "<a href='../view/cadastros.php'>CADASTROS</a>";
                            }
                        ?>
                    </li>
                    <li>
                        <?php
                            if($_SESSION['idAcessoUsuario']== 3)
                            {
                                echo "<a href='../view/cadastraMulher.php'>INÍCIO</a>";
                            }
                        ?>
                    </li>
                    <li>
                        <?php
                            if($_SESSION['idAcessoUsuario']== 4)
                            {
                                echo "<a href='../view/registraPresenca.php'>INÍCIO</a>";
                            }
                        ?>
                    </li>
                    <li><a>CONSULTAR</a>
                        <ul class="dropdown-menu">
                        <?php
                            if ($_SESSION['idAcessoUsuario'] == 1 || $_SESSION['idAcessoUsuario'] == 2) {
                                echo "
                                <li><a href='../view/consultaLocal.php'>LOCAIS</a></li>
                                <li><a href='../view/consultaNecessidade.php'>NECESSIDADES</a></li>
                                <li><a href='../view/consultaSecretaria.php'>SECRETARIA</a></li>
                                <li><a href='../view/consultaServico.php'>SERVIÇOS</a></li>";
                              } 
                            if($_SESSION['idAcessoUsuario'] == 1){
                                echo "<li><a href='../view/consultaFuncionario.php'>FUNCIONARIOS</a></li>";
                            }
                            if ($_SESSION['idAcessoUsuario'] != 4)  {
                                echo "<li><a href='../view/consultaMulher.php'>FICHAS</a></li>";
                            }
                            if($_SESSION['idAcessoUsuario'] != 3){
                                echo "<li><a href='../view/consultaInforme.php'>PRESENÇA</a></li>";
                            }
                            ?>              
                        </ul>
                    </li>
                    <?php
                        if($_SESSION['idAcessoUsuario'] == 1 || $_SESSION['idAcessoUsuario'] == 2) {
                            echo "<li><a href='../view/relatorio.php'>RELATÓRIO</a></li>";
                        }
                    ?>
                    <li><a href="../controller/fecharsessao.php" class="logout">SAIR</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <script src="./javascript/navbar.js" defer></script>