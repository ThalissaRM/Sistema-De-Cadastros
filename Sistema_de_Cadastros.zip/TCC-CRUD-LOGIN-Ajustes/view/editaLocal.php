<?php
     require_once '../model/conn.php';
     $con = new Conexao("nossoolhar", "localhost", "root", "");
     session_start();
    if(empty($_SESSION['idAcessoUsuario']) || ($_SESSION['idAcessoUsuario'] != '1') && ($_SESSION['idAcessoUsuario'] != '2')){
        session_destroy();
        header('Location: ../view/index.html');
        exit();
    }
     $_SESSION['returnPage'] = $_SERVER['HTTP_REFERER'];
     if (isset($_GET['codlocal_up'])) {
        $codlocal_update = addslashes($_GET['codlocal_up']);
        $res= $con->buscarDadosLocal($codlocal_update);
    }
    if(isset($_POST['txtLocal'])) {
        $codl = addslashes($_GET['codlocal_up']);
        $nomeLocal= addslashes($_POST['txtLocal']);
        $campos = array('txtLocal' => 'required | leng | texto');
        $countException = false;
        $regexTexto = "/^[A-Za-zÁáÂâÃãÉéÈèÊêÍíÏïÓóÔôÕõÖöÚúÇçÑñ'\s]+$/";
        foreach ($campos as $field => $value) 
        {
             try 
             {
                  if (strpos($value, 'required') !== false) 
                  {
                       if (empty(trim($_POST[$field])) || !isset($_POST[$field])) 
                       {
                            throw new Exception;
                       }
                  }
                  if (strpos($value, 'leng') !== false) 
                  {
                       if ((strlen(trim($_POST[$field])) <= 3)) 
                       {
                            throw new Exception;
                       }
                  }
                  if (strpos($value, 'texto') !== false) 
                  {
                       if (!preg_match($regexTexto, ($_POST[$field]) )) 
                       {
                            throw new Exception;
                       }
                  }
             } 
             catch (Exception $e) 
             {
                  echo $e->getMessage();
                  $countException = true;
             }
        }
        if (!$countException) 
        {
            echo"
            <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=consultaLocal.php'>
            <script>alert('Dados atualizados!')</script>";
            $con->atualizaDadosLocal($codl, $nomeLocal);
        }else{
            echo"
            <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=editaLocal.php'>
            <script>alert('Preencha todos os campos corretamente!')</script>"; 
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../view/images/logo_franco.jpg" type="image/jpg">
    <link rel="stylesheet" href="../view/css/returnPage.css">
    <link rel="stylesheet" href="../view/css/reset.css">
    <link rel="stylesheet" href="../view/css/style.css">
    <script defer src="../view/javascript/scripts.js"></script>
    <script defer src="../view/javascript/navbar.js"></script>
    <script src="https://kit.fontawesome.com/0e0aebece5.js" crossorigin="anonymous"></script>
    <title>Nosso Olhar | Editar Local</title>
</head>
<body class="edit-page">
    <?php
        include ('../view/header.php');
    ?>
    <main class="edit-page">
        <div class="edit-local">
            <h3>ATUALIZAR LOCAIS</h3>
            <form id="edit-local" method="POST">
                <div class="side-01">
                    <div class="box-local">
                        <span>LOCAL</span>
                        <input type="text" name="txtLocal" minlength="3" required placeholder="Local do Cadastro" size="40px" value="<?php if (isset($res)) {echo $res['NOMELOCAL'];}?> ">
                    </div>
                    <div class="box-local">
                        <input type="submit" value="Atualizar dados">
                    </div>
                </div>
            </form>
        </div>
        <?php include('../view/returnPage.php');?>
    </main>    
</body>
</html>