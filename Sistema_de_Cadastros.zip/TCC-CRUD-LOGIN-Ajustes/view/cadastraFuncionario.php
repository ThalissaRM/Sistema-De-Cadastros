<?php
    session_start();
    if(empty($_SESSION['idAcessoUsuario']) || ($_SESSION['idAcessoUsuario'] != '1')){
        session_destroy();
        header('Location: ../view/index.html');
        exit();
    }
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <link rel="shortcut icon" href="../view/images/logo_franco.jpg" type="image/jpg">
    <link rel="stylesheet" href="../view/css/reset.css">
    <link rel="stylesheet" href="../view/css/style.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- BIBLIOTECAS JQUERY PARA APLICAR MASCARA NO NUMERO DE REGISTRO-->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    <script src="../view/javascript/navbar.js"></script>  
    <script src="https://kit.fontawesome.com/0e0aebece5.js" crossorigin="anonymous"></script>
    <!-- IMPORTANTE -->
    <script src="../view/javascript/validates.js" defer></script> 
    <!--    !!!!!!   -->
    <title>Nosso Olhar | Cadastro de funcionário</title>
</head>
<body class="page-cad-func">
    <?php
        switch ($_SESSION['idAcessoUsuario']) {
            case '2':
                header('location: ../view/cadastros.php');
                break;
            case '3':
                header('location: ../view/cadastraMulher.php');
                break;
            
            case '4':
                header('location: ../view/registraPresenca.php');
                break;
        }
    ?>
    <?php
        include ('../view/header.php');
    ?>
    <main>
        <div class="container">
            <div class="form-cad-user">
              <div class="side-1">
                <label class="title-cad-user" for="Title"><span>CADASTRO DE FUNCIONÁRIO</span></label>
                <form id="form-cad-user" method="POST" action="../controller/validaFuncionario.php">
                    <div class="form-inputs">
                        <div class="input-box-cad-user">                     
                            <input type="text" name="txtNome" class="input required" required="required" oninput="verifyFirst()" id="alfabetico" minlength="3">
                            <span class="title-input">NOME COMPLETO</span>
                            <span class="span-message">O nome deve conter no mínimo 3 caracteres e apenas letras</span>
                        </div>
                        <div class="input-box-cad-user">                     
                            <input type="text" name="txtEmail" class="input required" required="required" oninput="verifySecond()" minlength="3">
                            <span class="title-input">E-MAIL</span>
                            <span class="span-message">Insira um e-mail válido</span>
                        </div>
                        <div class="input-box-cad-user">
                            <input type="text" name="txtNumRegistro" class="input required" oninput="verifySixth()" id="numRegistro" required="required" minlength="4" maxlength="6">
                            <span class="title-input">N° DO REGISTRO</span>
                            <span class="span-message">Digite apenas números válidos</span>
                        </div>
                        <div class="input-box-cad-user">
                            <input type="password" name="txtSenha" class="input required" required="required" oninput="verifySeventy()">
                            <span class="title-input">SENHA</span>
                            <span class="span-message">No mínimo 8 dígitos, letra minúscula, maiúscula, números e caracteres especiais</span>
                        </div>
                        <div class="input-box-cad-user">
                            <input type="password" class="input required" required="required" oninput="comparePass()">
                            <span class="title-input">CONFIRMAR SENHA</span>
                            <span class="span-message">As senhas não coincidem</span>
                        </div>
                        <div class="select-nivel-acess">
                            <select name="CodNivel" id="selectField">
                                <option value="">NÍVEL DE ACESSO</option>
                                <option value="adm">ADMINISTRADOR</option>
                                <option value="mod">MODERADOR</option>
                                <option value="func">FUNCIONÁRIO</option>
                                <option value="info">INFORME</option>
                            </select>
                        </div>
                        <div class="btn-cad-user">
                            <button>CADASTRAR</button>
                        </div>
                    </div>
                </form>                
              </div>
              <div class="side-2">
                <div class="image-woman-page-02">
                    <img src="../view/images/undraw_people_re_8spw.svg" alt="Mulher">
                </div>
            </div>
            </div>
        </div>
    </main>
    <script src="javascript/lgpd.js">


</script>
</body>
</html>