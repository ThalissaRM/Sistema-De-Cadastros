<?php
    require_once '../model/conn.php';
    $con = new Conexao("nossoolhar", "localhost", "root", "");
    session_start();
    if(empty($_SESSION['idAcessoUsuario']) || ($_SESSION['idAcessoUsuario'] != '1') && ($_SESSION['idAcessoUsuario'] != '2')){
        session_destroy();
        header('Location: ../view/index.html');
        exit();
    }

    $_SESSION['returnPage'] = $_SERVER['HTTP_REFERER'];
    if (isset($_GET['codsecretaria_up'])) {
        $CodSecretaria = addslashes($_GET['codsecretaria_up']);
    }
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../view/images/logo_franco.jpg" type="image/jpg">
    <link rel="stylesheet" href="../view/css/returnPage.css">
    <link rel="stylesheet" href="../view/css/reset.css">
    <link rel="stylesheet" href="../view/css/style.css">
    <script defer src="../view/javascript/scripts.js"></script>
    <script defer src="../view/javascript/navbar.js"></script>
    <script src="https://kit.fontawesome.com/0e0aebece5.js" crossorigin="anonymous"></script>
    <title>Nosso Olhar | Consulta Serviços</title>
</head>
<body class="search-page">
<?php
        include('../view/header.php');
    ?>

    <div class="container-for-tables">
        <table class="table-style">
            <tr class="title-table">
                <td class="title-table">Serviços</td>
            </tr>

        <?php
            $res = $con->query("SELECT CODSERVICO_SECRETARIA, NOMESERVICO, NOMESECRETARIA FROM SERVICO_SECRETARIA INNER JOIN SERVICO ON SERVICO_SECRETARIA.CODSERVICO = SERVICO.CODSERVICO INNER JOIN SECRETARIA ON SERVICO_SECRETARIA.CODSECRETARIA_SS = SECRETARIA.CODSECRETARIA WHERE SERVICO.APARECER LIKE '1' AND SERVICO_SECRETARIA.CODSECRETARIA_SS LIKE '$CodSecretaria'");
            $dados = $res->fetchAll(PDO::FETCH_ASSOC);

            $secretaria = count($dados);

                  for ($i=0; $i < count($dados); $i++) { 
                
                    foreach ($dados[$i] as $key => $value) { 
                    $servicos = $dados[$i]['NOMESERVICO'];
            }
        ?>
    <tr class="row-table">
        <td><span><?php echo $servicos;?></span></td>
    </tr>

    <?php } ?>

        </table>
        <?php include('../view/returnPage.php');?>
    </div>
</body>
</html>