<div class="return-page" onclick="location.href='<?php echo $_SESSION['returnPage'];?>'">
    <i class="fa-solid fa-chevron-left"></i>
    <span>Voltar</span>
</div>