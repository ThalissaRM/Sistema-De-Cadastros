<?php
    require_once '../model/conn.php';
    $con = new Conexao("nossoolhar", "localhost", "root", "");
    session_start();
    $_SESSION['returnPage'] = $_SERVER['HTTP_REFERER'];   
    if(empty($_SESSION['idAcessoUsuario']) || ($_SESSION['idAcessoUsuario'] != '1') && ($_SESSION['idAcessoUsuario'] != '2') && ($_SESSION['idAcessoUsuario'] != '4') ){
        session_destroy();
        header('Location: ../view/index.html');
        exit();
    }
    
?>


<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../view/images/logo_franco.jpg" type="image/jpg">
    <link rel="stylesheet" href="../view/css/returnPage.css">
    <link rel="stylesheet" href="../view/css/reset.css">
    <link rel="stylesheet" href="../view/css/style.css">
    <script defer src="../view/javascript/scripts.js"></script>
    <script defer src="../view/javascript/navbar.js"></script>
    <script src="https://kit.fontawesome.com/0e0aebece5.js" crossorigin="anonymous"></script>
    <title>Nosso Olhar | Presença</title>
</head>
<body class="search-page">
    <?php
        include('../view/header.php');
    ?>
    <div class="container-for-tables">
        <?php
            if (isset($_GET['informe'])){
            $codinforme = addslashes($_GET['informe']);
            $con->excluirInforme($codinforme);
            header("location: consultaInforme.php");
            }
        ?>

        <div class="search-bar">
            <form class="search-box">
                <input type="search" aria-label="Search" placeholder="Pesquisar..." aria-label="Search" name="txtbuscar">
                <button type="submit" name="buscar"><i class="fa-solid fa-magnifying-glass"></i></button>                
            </form>
        </div>

        <table class="table-style">
            <tr class="title-table">
                <td class="title-table" colspan="9">Consultar presenças</td>
            </tr>
            <tr class="title-table">
                <td class="title-table">Data comparecimento</td>
                <td class="title-table">Início</td>
                <td class="title-table">Término</td>
                <td class="title-table">Funcionário</td>
                <td class="title-table">Secretaria</td>
                <td class="title-table">Serviço</td>
                <td class="title-table">Compareceu?</td>
                <td class="title-table">Mulher</td>
                <td class="title-table">Ações</td>
            </tr>
            <?php
                if(isset($_GET['buscar']) and $_GET['txtbuscar'] != ''){
                    $nome_buscar = $_GET['txtbuscar'] . '%';
                    $res = $con->query("SELECT CODINFORME, DATACOMPARECIMENTO, HRINICIO, HRTERMINO, NOME_FUNCIONARIO, NOMESECRETARIA, NOMESERVICO, TIPOSITUACAO, NOME, NIVEL_ACESSO FROM INFORME INNER JOIN CADUSUARIO ON INFORME.NUMREGISTROI = CADUSUARIO.NUMREGISTRO INNER JOIN SERVICO_SECRETARIA ON INFORME.CODSERVICO_SECRETARIA = SERVICO_SECRETARIA.CODSERVICO_SECRETARIA INNER JOIN SERVICO ON SERVICO_SECRETARIA.CODSERVICO = SERVICO.CODSERVICO INNER JOIN SECRETARIA ON SERVICO_SECRETARIA.CODSECRETARIA_SS = SECRETARIA.CODSECRETARIA INNER JOIN SITUACAO ON INFORME.CODSITUACAO = SITUACAO.CODSITUACAO INNER JOIN MULHER ON INFORME.CODMULHER = MULHER.CODMULHER WHERE NOME LIKE '$nome_buscar' AND INFORME.APARECER = '1' AND NIVEL_ACESSO ='". $_SESSION['idAcessoUsuario']."'");
                } else {
                    $res = $con->query("SELECT CODINFORME, DATACOMPARECIMENTO, HRINICIO, HRTERMINO, NOME_FUNCIONARIO, NOMESECRETARIA, NOMESERVICO, TIPOSITUACAO, NOME, NIVEL_ACESSO FROM INFORME INNER JOIN CADUSUARIO ON INFORME.NUMREGISTROI = CADUSUARIO.NUMREGISTRO INNER JOIN SERVICO_SECRETARIA ON INFORME.CODSERVICO_SECRETARIA = SERVICO_SECRETARIA.CODSERVICO_SECRETARIA INNER JOIN SERVICO ON SERVICO_SECRETARIA.CODSERVICO = SERVICO.CODSERVICO INNER JOIN SECRETARIA ON SERVICO_SECRETARIA.CODSECRETARIA_SS = SECRETARIA.CODSECRETARIA INNER JOIN SITUACAO ON INFORME.CODSITUACAO = SITUACAO.CODSITUACAO INNER JOIN MULHER ON INFORME.CODMULHER = MULHER.CODMULHER  WHERE INFORME.APARECER = '1' AND NIVEL_ACESSO ='". $_SESSION['idAcessoUsuario']."'");
                }
                $dados = $res->fetchAll(PDO::FETCH_ASSOC);
                $informes = count($dados);
                
                for ($i=0; $i < count($dados); $i++) {
                    foreach ($dados[$i] as $key => $value) {
                    $datacomparecimento = $dados[$i]['DATACOMPARECIMENTO'];
                    $hrinicio = $dados[$i]['HRINICIO'];
                    $hrtermino = $dados[$i]['HRTERMINO'];
                    $nome_funcionario = $dados[$i]['NOME_FUNCIONARIO'];
                    $nomesecretaria = $dados[$i]['NOMESECRETARIA'];
                    $nomeservico = $dados[$i]['NOMESERVICO'];
                    $tiposituacao = $dados[$i]['TIPOSITUACAO'];
                    $nomemulher = $dados[$i]['NOME'];
                }
            ?>
            <tr class="row-table">
                <td><?php echo $datacomparecimento; ?></td>
                <td><?php echo $hrinicio; ?></td>
                <td><?php echo $hrtermino; ?></td>
                <td><?php echo $nome_funcionario; ?></td>
                <td><?php echo $nomesecretaria; ?></td>
                <td><?php echo $nomeservico; ?></td>
                <td>
                    <?php if($tiposituacao == 0) {
                        echo "Não";
                    } else {
                        echo "Sim";
                    }
                    ?>
                </td>
                <td><?php echo $nomemulher; ?></td>
                <td class="icon-column">
                    <a href="editaInforme.php?codinforme_up=<?php echo $dados [$i] ['CODINFORME']?>"><i class="fa-solid fa-pencil"></i></a>
                    <?php
                    if ($_SESSION['idAcessoUsuario'] == 1 || $_SESSION['idAcessoUsuario'] == 2){
                        echo '<a href="consultaInforme.php?informe=' . $dados[$i]['CODINFORME'] . '" onclick="return confirm(\'Deseja realmente excluir?\')"><i class="fa-solid fa-trash"></i></a>';
                    }
                    ?>
                
                </td>
            </tr>
            <?php } ?>
        </table>
        <?php include('../view/returnPage.php');?>
</body>
</html>