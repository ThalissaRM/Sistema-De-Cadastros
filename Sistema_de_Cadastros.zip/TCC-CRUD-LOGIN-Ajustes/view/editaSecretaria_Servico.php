<?php 
    require_once '../model/conn.php';
    $con = new Conexao("nossoolhar", "localhost", "root", "");
    session_start();
    if(empty($_SESSION['idAcessoUsuario']) || ($_SESSION['idAcessoUsuario'] != '1') && ($_SESSION['idAcessoUsuario'] != '2')){
        session_destroy();
        header('Location: ../view/index.html');
        exit();
    }
    $_SESSION['returnPage'] = $_SERVER['HTTP_REFERER'];
    if (isset($_GET['codsecretaria_up'])) {
        $codsecretaria_update = addslashes($_GET['codsecretaria_up']);
        $res= $con->buscarDadosSecretaria($codsecretaria_update);
    }
    if(isset($_POST['txtSecretaria'])) {
        $codsecretaria = addslashes($_GET['codsecretaria_up']);
        $nomeSecretaria= addslashes($_POST['txtSecretaria']);
        $servicosSelecionados= $_POST['selectServicos'];
        $campos = array('txtSecretaria' => 'required | leng | texto',
        'selectServicos' => 'required',); 
        $countException = false;
        $regexTexto = "/^[A-Za-zÁáÂâÃãÉéÈèÊêÍíÏïÓóÔôÕõÖöÚúÇçÑñ'\s]+$/";
        foreach ($campos as $field => $value) 
        {
             try 
             {
                if (strpos($value, 'required') !== false){
                    if (empty($_POST[$field]) || !isset($_POST[$field])) 
                       {
                            throw new Exception;
                       }
                  }
                  if (strpos($value, 'leng') !== false) 
                  {
                    if ((strlen(trim($_POST[$field])) <= 3)) 
                       {
                            throw new Exception;
                       }
                  }
                  if (strpos($value, 'texto') !== false) 
                  {
                    if (!preg_match($regexTexto, ($_POST[$field]) )) 
                       {
                            throw new Exception;
                       }
                  }
             } 
            catch (Exception $e) 
             {
                  echo $e->getMessage();
                  $countException = true;
             }
        }
        if (!$countException) {
            echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=consultaSecretaria.php'>
            <script>alert('Dados atualizados!')</script>"; 
            $con->atualizarDadosSecretaria($codsecretaria, $nomeSecretaria, $servicosSelecionados);
        } else{
            echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=editaSecretaria_Servico.php'>
            <script>alert('Preencha todos os campos corretamente!')</script>"; 
        }
    }
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../view/images/logo_franco.jpg" type="image/jpg">
    <link rel="stylesheet" href="../view/css/returnPage.css">
    <link rel="stylesheet" href="../view/css/reset.css">
    <link rel="stylesheet" href="../view/css/style.css">
    <script defer src="../view/javascript/navbar.js"></script>
    <script defer src="../view/javascript/scripts.js"></script>
    <script src="https://kit.fontawesome.com/0e0aebece5.js" crossorigin="anonymous"></script>
    <title>Nosso Olhar | Editar secretaria</title>
</head>
<body class="edit-page">
    <?php
        include ('../view/header.php');
    ?>
    <main class="edit-page">
        <div class="edit-secretary">
            <h3>ATUALIZAR DADOS</h3>
            <form id="edit-secretary" method="POST">
                <div class="side-01">
                    <div class="box-secretary">
                        <span>SECRETARIA</span>
                        <input type="text" name="txtSecretaria" minlength="3" required value="<?php if (isset($res)) {echo $res['NOMESECRETARIA'];}?>">
                    </div>
                    <div class="box-secretary">
                        <span>SERVIÇO ASSOCIADO</span>
                        <select name="selectServicos[]" class="js-example-basic-multiple" multiple="multiple" required>
                            <option value="">Clique para selecionar</option>
                            <?php
                                require_once '../model/conn.php';  
                                $con = new Conexao("nossoolhar","localhost","root",""); 
                                $select = "SELECT * FROM SERVICO WHERE APARECER LIKE '1'";
                                $param = $con->query($select);
                                while ($select = $param->fetch(PDO::FETCH_ASSOC)){
                                echo '<option value="'.$select["CODSERVICO"]. '">';           
                                    echo $select ["NOMESERVICO"];        
                                }    
                            ?>
                        </select>
                    </div>
                    <div class="box-secretary">
                        <input type="submit" value="Atualizar dados">
                    </div>
                </div>
            </form>
        </div>
        <?php include('../view/returnPage.php');?>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>$(document).ready(function() {
    $('.js-example-basic-multiple').select2();
    });
    </script>
</body>
</html>