<?php
    require_once '../model/conn.php';
    $con = new Conexao("nossoolhar", "localhost", "root", "");
    session_start();
    if(empty($_SESSION['idAcessoUsuario']) || ($_SESSION['idAcessoUsuario'] != '1') && ($_SESSION['idAcessoUsuario'] != '2') && ($_SESSION['idAcessoUsuario'] != '4') ){
        session_destroy();
        header('Location: ../view/index.html');
        exit();
    }

    $_SESSION['returnPage'] = $_SERVER['HTTP_REFERER'];
    if (isset($_GET['codinforme_up'])) {
    
    $codinforme_update = addslashes($_GET['codinforme_up']);
    
    $res= $con->buscarDadosInforme($codinforme_update);
    }
    
    if(isset($_POST['dtComparecimento'])) {
        $codinforme = addslashes($_GET['codinforme_up']);
        $dataComparecimento = addslashes($_POST['dtComparecimento']);
        $horaInicio= addslashes($_POST['tmHoraInicio']);
        $horaTermino= addslashes($_POST['tmHoraTermino']);
        $selfuncionario = $_POST['selectfuncionario'];
        $selservicosecretaria = $_POST['selectsecretaria_servicoi'];
        $selsituacao = $_POST['selectSituacao'];
        $selmulher = $_POST['selectmulher'];
        $campos = array('dtComparecimento' => ' | required ',
        'tmHoraInicio' => 'required',
        'tmHoraTermino' => 'required',
        'selectfuncionario' => 'required',
        'selectsecretaria_servicoi' => 'required',
        'selectmulher' => 'required',
        'selectSituacao' => 'required',
        );
        $countException = false;
        $regexTexto = "/^[A-Za-zÁáÂâÃãÉéÈèÊêÍíÏïÓóÔôÕõÖöÚúÇçÑñ'\s]+$/";
        foreach ($campos as $field => $value)  {
               try {
                    if (strpos($value, 'required') !== false) {
                         if (empty($_POST[$field]) || !isset($_POST[$field])) 
                         {
                              throw new Exception;
                         }
                    }
               }
               catch (Exception $e) {
                    echo $e->getMessage();
                    $countException = true;
               }
          }
        if (!$countException) {
            
            echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=consultaInforme.php'>
            <script>alert('Dados atualizados!')</script>";
            $con->atualizaDadosInforme($codinforme, $dataComparecimento, $horaInicio, $horaTermino, $selfuncionario, $selservicosecretaria, $selsituacao, $selmulher);
        } else{
            echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=editaInforme.php'>
            <script>alert('Preencha todos os campos corretamente!')</script>"; 
        }

    }
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../view/images/logo_franco.jpg" type="image/jpg">
    <link rel="stylesheet" href="../view/css/returnPage.css">
    <link rel="stylesheet" href="../view/css/reset.css">
    <link rel="stylesheet" href="../view/css/style.css">
    <script defer src="../view/javascript/navbar.js"></script>
    <script defer src="../view/javascript/scripts.js"></script>
    <script src="https://kit.fontawesome.com/0e0aebece5.js" crossorigin="anonymous"></script>
    <title>Nosso Olhar | Editar Presença</title>
</head>
<body class="edit-page">
    <?php
        include ('../view/header.php');
    ?>
    <main class="edit-page">
        <div class="edit-presence">
        <h3>ATUALIZAR DADOS</h3>
            <form id="edit-presence" method="POST">
                <div class="side-01">
                    <div class="box-presence">
                        <span>DATA DO COMPARECIMENTO</span>
                        <input type="date" name="dtComparecimento" required value="<?php if (isset($res)) {echo $res['DATACOMPARECIMENTO'];}?>">
                    </div>
                    <div class="box-presence">
                        <span>HORA DE INÍCIO</span>
                        <input type="time" name="tmHoraInicio" required value="<?php if (isset($res)) {echo $res['HRINICIO'];}?>">
                    </div>
                    <div class="box-presence">
                        <span>HORA DE TÉRMINO</span>
                        <input type="time" name="tmHoraTermino" required value="<?php if (isset($res)) {echo $res['HRTERMINO'];}?>">
                    </div>
                    <div class="box-presence">
                        <span>SELECIONE O FUNCIONÁRIO</span>
                        <select name="selectfuncionario" id="" required>
                            <option value="">Clique para selecionar</option>
                            <?php
                                require_once '../model/conn.php';  
                                $con = new Conexao("nossoolhar","localhost","root",""); 
                                $select = "SELECT * FROM CADUSUARIO  WHERE APARECER LIKE '1'";
                                $param = $con->query($select);
                                while ($select = $param->fetch(PDO::FETCH_ASSOC)){
                                    ?>

                                    <option value="<?php echo $select['NUMREGISTRO'];?>"  <?php echo $res ['NUMREGISTROI'] == $select['NUMREGISTRO'] ? 'selected' : '';?>>
                                    <?php echo $select ['NOME_FUNCIONARIO'];?>
 
                                     </option>
                         <?php
                                 }
                             ?>
                         </select>

                    </div>
                </div>
                <div class="side-02">
                    <div class="box-presence">
                        <span>SELECIONE A MULHER</span>
                        <select name="selectmulher" id="" required>
                            <option value="">Clique para selecionar</option>
                            <?php
                                require_once '../model/conn.php';  
                                $con = new Conexao("nossoolhar","localhost","root",""); 
                                $select = "SELECT * FROM MULHER  WHERE APARECER LIKE '1'";
                                $param = $con->query($select);
                                while ($select = $param->fetch(PDO::FETCH_ASSOC)){
                                    ?>

                                    <option value="<?php echo $select['CODMULHER'];?>"  <?php echo $res ['CODMULHER'] == $select['CODMULHER'] ? 'selected' : '';?>>
                                    <?php echo $select ['NOME'];?>
 
                                     </option>
                         <?php
                                 }
                             ?>
                        </select>  
                    </div>
                    <div class="box-presence">
                        <span>COMPARECEU AO SERVIÇO?</span>
                        <select name="selectSituacao" required>
                        <option value="">Compareceu ao serviço?</option>
                        <?php
                        require_once '../model/conn.php';  
                        $con = new Conexao("nossoolhar","localhost","root",""); 
                        $select = "SELECT * FROM SITUACAO";
                        $param = $con->query($select);
                        while ($select = $param->fetch(PDO::FETCH_ASSOC))
                        {
                            ?>

                            <option value="<?php echo $select['CODSITUACAO'];?>"  <?php echo $res ['CODSITUACAO'] == $select['CODSITUACAO'] ? 'selected' : '';?>>
                            
                           
                 <?php
                        
                if($select['TIPOSITUACAO']==0){

                echo "Não";
                }
                else{

                echo "Sim";
                 }
                echo "</option>";
                    }
                 ?>
                    </select>

                    </div>
                    <div class="box-presence">
                        <span>SELECIONE A SECRETARIA E O SERVIÇO</span>
                        <select name="selectsecretaria_servicoi" required>
                            <option value="">Clique para selecionar</option>
                            <?php
                                require_once '../model/conn.php';  
                                $con = new Conexao("nossoolhar","localhost","root",""); 
                                $select = "SELECT CODSERVICO_SECRETARIA, NOMESECRETARIA, NOMESERVICO FROM SERVICO_SECRETARIA JOIN SECRETARIA ON SERVICO_SECRETARIA.CODSECRETARIA_SS = SECRETARIA.CODSECRETARIA JOIN SERVICO ON SERVICO_SECRETARIA.CODSERVICO = SERVICO.CODSERVICO
                                 WHERE SECRETARIA.APARECER LIKE '1' AND SERVICO.APARECER LIKE '1'";
                                $param = $con->query($select);
                                while($select = $param->fetch(PDO::FETCH_ASSOC)){
                                    ?>

                                    <option value="<?php echo $select['CODSERVICO_SECRETARIA'];?>"  <?php echo $res ['CODSERVICO_SECRETARIA'] == $select['CODSERVICO_SECRETARIA'] ? 'selected' : '';?>>
                                    <?php echo $select ['NOMESECRETARIA'];
                                    echo " -";
                                    echo $select ["NOMESERVICO"];
                                    
                                    ?>
 
                                     </option>
                         <?php
                                 }
                             ?>
                                
                            
                        </select>
                    </div>
                    <div class="box-presence">
                        <input type="submit" value="Atualizar dados">
                    </div>
                </div>
            </form>
        </div>
        <?php include('../view/returnPage.php');?>
    </main>
</body>
</html>