<?php
       session_start();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <link rel="shortcut icon" href="../view/images/logo_franco.jpg" type="image/jpg">
    <link rel="stylesheet" href="../view/css/reset.css">
    <link rel="stylesheet" href="../view/css/style.css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    <script defer src="../view/javascript/valida.js"></script>
    <script defer src="../view/javascript/registraPresenca.js"></script>
    <script src="../view/javascript/navbar.js"></script>
    <script src="https://kit.fontawesome.com/0e0aebece5.js" crossorigin="anonymous"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nosso Olhar | Registrar presença</title>
</head>
<body class="register-presence-page">
    <div class="overlay">
    </div>
    <div class="input-return" onclick="returnPage()">
        <i class="fa-solid fa-xmark"></i>
        <input id="input-set-return" onclick="returnPage()" type="submit" value="">
    </div>
    <?php
        include('../view/header.php');
    ?>
    <main class="presence-page">
        <div class="open-presence-register">
            <div class="background-image-presence-register">
                <div class="image-main-01">
                    <img src="../view/images/undraw_time_management_re_tk5w.svg" alt="Register Presence">
                </div>
                <div class="box-form-open-form">
                    <input class="open-presence-form" type="button" value="registrar presença">
                </div>
            </div>
        </div>
        <div class="cad-presence-form">
            <form id="form-presence" method="POST" action="../controller/validaInforme.php">
                <div class="box-presence">
                    <span>DATA DO COMPARECIMENTO</span>
                    <input type="date" name="dtComparecimento">
                </div>
                <div class="box-presence">
                    <span>HORA DE INÍCIO</span>
                    <input type="time" name="tmHoraInicio">
                </div>
                <div class="box-presence">
                    <span>HORA DE TÉRMINO</span>
                    <input type="time" name="tmHoraTermino">
                </div>
                <div class="box-presence">
                    <span>Selecione o funcionário responsável</span>
                    <select name="selectFuncionario">
                        <option>Clique para selecionar</option>
                        <?php
                            require_once '../model/conn.php';  
                            $con = new Conexao("nossoolhar","localhost","root",""); 
                            $select = "SELECT * FROM CADUSUARIO WHERE NUMREGISTRO ='". $_SESSION['idAcesso']."'";
                            $param = $con->query($select);
                            while ($select = $param->fetch(PDO::FETCH_ASSOC)){
                                echo '<option value="'.$select["NUMREGISTRO"]. '">';
                                echo $select ["NOME_FUNCIONARIO"];
                                echo '</label><br><br>';
                            }                        
                        ?>
                    </select>
                </div>
                <div class="box-presence">
                    <span>Selecione a mulher</span>
                    <select name="selectMulher">
                        <option>Clique para selecionar</option>
                        <?php
                            require_once '../model/conn.php';  
                            $con = new Conexao("nossoolhar","localhost","root",""); 
                            $select = "SELECT * FROM MULHER";
                            $param = $con->query($select);
                            while ($select = $param->fetch(PDO::FETCH_ASSOC)){
                                echo '<option value="'.$select["CODMULHER"]. '">';
                                echo $select ["NOME"];
                                echo '</label><br><br>';
                            }
                        ?>
                    </select>
                </div>
                <div class="box-presence">
                    <span>Compareceu ao serviço?</span>
                    <select name="selectSituacao">
                        <option>Clique para selecionar</option>
                        <?php
                        require_once '../model/conn.php';  
                        $con = new Conexao("nossoolhar","localhost","root",""); 
                        $select = "SELECT * FROM SITUACAO";
                        $param = $con->query($select);
                        while ($select = $param->fetch(PDO::FETCH_ASSOC))
                        {
                        echo '<option value="'.$select["CODSITUACAO"].'"';
                        if($select['TIPOSITUACAO']==0){
                            echo ">Não";
                        }
                        else{
                            echo ">Sim";
                        }
                            echo "</option>";
                    }
                ?>
                    </select>
                </div>
                <div class="box-presence">
                    <span>Selecione a secretaria e o serviço</span>
                    <select name="selectSecretaria_Servico">
                        <option>Clique para selecionar</option>
                        <?php
                            require_once '../model/conn.php';  
                            $con = new Conexao("nossoolhar","localhost","root",""); 
                            $select = "SELECT CODSERVICO_SECRETARIA, NOMESECRETARIA, NOMESERVICO FROM SERVICO_SECRETARIA INNER JOIN SERVICO ON 
                            SERVICO_SECRETARIA.CODSERVICO = SERVICO.CODSERVICO INNER JOIN SECRETARIA ON SERVICO_SECRETARIA.CODSECRETARIA_SS = SECRETARIA.CODSECRETARIA";
                            $param = $con->query($select);
                            while($select = $param->fetch(PDO::FETCH_ASSOC)){
                                echo '<option value="'.$select["CODSERVICO_SECRETARIA"]. '">';
                                echo $select ["NOMESECRETARIA"]; 
                                echo " -";
                                echo $select ["NOMESERVICO"];
                                echo '</option><br><br>';
                            }
                        ?>
                    </select>
                </div>
                <div class="box-presence">
                    <input type="submit" value="registrar">
                </div>
            </form>
        </div>
    </main>
</body>
</html>