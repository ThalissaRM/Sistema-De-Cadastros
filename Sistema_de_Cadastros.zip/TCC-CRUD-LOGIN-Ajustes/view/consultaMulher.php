<?php
    require_once '../model/conn.php';
    $con = new Conexao("nossoolhar", "localhost", "root", "");
    session_start();

    $_SESSION['returnPage'] = $_SERVER['HTTP_REFERER'];
    if(empty($_SESSION['idAcessoUsuario']) || ($_SESSION['idAcessoUsuario'] != '1') && ($_SESSION['idAcessoUsuario'] != '2')  && ($_SESSION['idAcessoUsuario'] != '3')){
        session_destroy();
        header('Location: ../view/index.html');
        exit();
    }

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../view/images/logo_franco.jpg" type="image/jpg">
    <link rel="stylesheet" href="../view/css/returnPage.css">
    <link rel="stylesheet" href="../view/css/reset.css">
    <link rel="stylesheet" href="../view/css/style.css">
    <script defer src="../view/javascript/scripts.js"></script>
    <script defer src="../view/javascript/navbar.js"></script>
    <script src="https://kit.fontawesome.com/0e0aebece5.js" crossorigin="anonymous"></script>
    <title>Nosso Olhar | Consulta de mulheres</title>
</head>
<body class="search-page">
    <?php
        include('../view/header.php');
    ?>
    <div class="container-for-tables">
        <?php
            if (isset($_GET['mulher'])) {
            $codmulher = addslashes($_GET['mulher']);
            $con->excluirMulher($codmulher);
            header("location: consultaMulher.php");
            }
        ?>
        
        <div class="search-bar">
            <form class="search-box">
                <input type="search" aria-label="Search" class="input-search" name="txtbuscar" placeholder="Pesquisar...">
                <button type="submit" name="buscar"><i class="fa-solid fa-magnifying-glass"></i></button>                
            </form>
        </div>
        
        <table class="table-style">
            <tr class="title-table">
                <td class="title-table" colspan="10">
                    Consultar mulheres
                </td>
            </tr>
            <tr class="title-table">
                <td class="title-table">Nome</td>
                <td class="title-table">Bairro</td>
                <td class="title-table">Email</td>
                <td class="title-table">Celular</td>
                <td class="title-table">Telefone</td>
                <td class="title-table">Data de nascimento</td>
                <td class="title-table">Local de cadastro</td>
                <td class="title-table">Funcionário</td>
                <td class="title-table">Necessidade</td>
                <td class="title-table">Ações</td>
            </tr>

        <?php

            if(isset($_GET['buscar']) and $_GET['txtbuscar'] != '') {
                $nome_buscar = $_GET['txtbuscar'] . '%';            
                $res = $con->query("SELECT CODMULHER, NOME, BAIRRO, EMAIL, CEL, TEL, DTNASC, NOMELOCAL, NOME_FUNCIONARIO, NIVEL_ACESSO FROM MULHER INNER JOIN LOCALCADASTRO ON MULHER.CODLOCALCADASTRO = LOCALCADASTRO.CODLOCALCADASTRO INNER JOIN CADUSUARIO ON MULHER.NUMREGISTROM = CADUSUARIO.NUMREGISTRO  WHERE MULHER.APARECER LIKE '1' AND NOME LIKE '$nome_buscar' OR EMAIL LIKE '$nome_buscar' AND NIVEL_ACESSO ='". $_SESSION['idAcessoUsuario']."'");             
            }else {
                $res = $con->query("SELECT CODMULHER, NOME, BAIRRO, EMAIL, CEL, TEL, DTNASC, NOMELOCAL, NOME_FUNCIONARIO, NIVEL_ACESSO FROM MULHER INNER JOIN LOCALCADASTRO ON MULHER.CODLOCALCADASTRO = LOCALCADASTRO.CODLOCALCADASTRO INNER JOIN CADUSUARIO ON MULHER.NUMREGISTROM = CADUSUARIO.NUMREGISTRO  WHERE MULHER.APARECER LIKE '1' AND NIVEL_ACESSO ='". $_SESSION['idAcessoUsuario']."'");
            }

            $dados = $res->fetchAll(PDO::FETCH_ASSOC);

            $mulheres = count($dados);

                  for ($i=0; $i < count($dados); $i++) { 
                
                    foreach ($dados[$i] as $key => $value) { 
    
                    $nome = $dados[$i]['NOME'];
                    $bairro = $dados[$i]['BAIRRO'];
                    $email = $dados[$i]['EMAIL'];
                    $cel = $dados[$i]['CEL'];
                    $tel = $dados[$i]['TEL'];
                    $dtnasc = $dados[$i]['DTNASC'];
                    $nomelocal = $dados[$i]['NOMELOCAL'];
                    $nomefuncionario = $dados[$i]['NOME_FUNCIONARIO'];
                    // $necessidade = $dados[$i]['NECESSIDADE'];
            }
        ?>

    <tr class="row-table">
        <td><span><?php echo $nome;?></span></td>
        <td><span><?php echo $bairro;?></span></td>
        <td><span><?php echo $email;?></span></td>
        <td><span><?php echo $cel;?></span></td>
        <td><span><?php echo $tel;?></span></td>
        <td><span><?php echo $dtnasc;?></span></td>
        <td><span><?php echo $nomelocal;?></span></td>
        <td><span><?php echo $nomefuncionario;?></span></td>
        
        <td> <a href="../view/consultaNecessidadeMulher.php?codmulher_up=<?php echo $dados [$i] ['CODMULHER'] ?>"><button> Visualizar</button></i></td>

        <td class="icon-column">
            <a href="../view/editaMulher.php?codmulher_up=<?php echo $dados [$i] ['CODMULHER'] ?>"><i class="fa-solid fa-pencil"></i></a>
            <?php
                if($_SESSION['idAcessoUsuario'] == 1) {
                    echo "<a href='../view/editaMulher.php?codmulher_up=" . $dados [$i] ['CODMULHER'] ."<i class='fa-solid fa-trash'></i></a>";
                }
            ?>
            <a href="consultaMulher.php?mulher=<?php echo $dados [$i] ['CODMULHER'] ?>" onclick="return confirm('Deseja realmente excluir?')"><i class="fa-solid fa-trash"></i></a>
        </td>
    </tr>

    <?php } ?>

        </table>
        <?php include('../view/returnPage.php');?>
    </div>
</body>
</html>