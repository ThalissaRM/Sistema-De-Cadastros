<?php
    require_once '../model/conn.php';
    $con = new Conexao("nossoolhar", "localhost", "root", "");
    session_start();
    if(empty($_SESSION['idAcessoUsuario']) || ($_SESSION['idAcessoUsuario'] != '1') && ($_SESSION['idAcessoUsuario'] != '2') && ($_SESSION['idAcessoUsuario'] != '3')){
        session_destroy();
        header('Location: ../view/index.html');
        exit();
    }
    $_SESSION['returnPage'] = $_SERVER['HTTP_REFERER'];
    if (isset($_GET['codmulher_up'])) {
        $CodMulher = addslashes($_GET['codmulher_up']);
    }

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../view/images/logo_franco.jpg" type="image/jpg">
    <link rel="stylesheet" href="../view/css/returnPage.css">
    <link rel="stylesheet" href="../view/css/reset.css">
    <link rel="stylesheet" href="../view/css/style.css">
    <script defer src="../view/javascript/scripts.js"></script>
    <script defer src="../view/javascript/navbar.js"></script>
    <script src="https://kit.fontawesome.com/0e0aebece5.js" crossorigin="anonymous"></script>
    <title>Nosso Olhar | Consulta de Necessidades</title>
</head>
<body class="search-page">
<?php
        include('../view/header.php');
    ?>

    <div class="container-for-tables">
        
        <!-- <div class="search-bar">
            <form class="search-box">
                <input type="search" aria-label="Search" class="input-search" name="txtbuscar" placeholder="Pesquisar...">
                <button type="submit" name="buscar"><i class="fa-solid fa-magnifying-glass"></i></button>                
            </form>
        </div> -->
        
        <table class="table-style">
            <tr class="title-table">
                <td class="title-table">Necessidade</td>
            </tr>

        <?php
            // if(isset($_GET['buscar']) and $_GET['txtbuscar'] != '') {
            //     $nome_buscar = $_GET['txtbuscar'] . '%';       
            //     $res = $con->query("SELECT NECESSIDADE FROM MULHER JOIN NECESSIDADEMULHER ON MULHER.CODMULHER = NECESSIDADEMULHER.CODMULHER_N JOIN NECESSIDADE ON NECESSIDADEMULHER.CODNECESSIDADE = NECESSIDADE.CODNECESSIDADE  WHERE MULHER.APARECER LIKE '1' AND NECESSIDADE LIKE '$nome_buscar' AND NECESSIDADEMULHER.CODMULHER_N LIKE '$CodMulher'");                
            // }else {
                $res = $con->query("SELECT NECESSIDADE FROM MULHER JOIN NECESSIDADEMULHER ON MULHER.CODMULHER = NECESSIDADEMULHER.CODMULHER_N JOIN NECESSIDADE ON NECESSIDADEMULHER.CODNECESSIDADE = NECESSIDADE.CODNECESSIDADE  WHERE NECESSIDADE.APARECER LIKE '1' AND NECESSIDADEMULHER.CODMULHER_N LIKE '$CodMulher' ");
            // }
            $dados = $res->fetchAll(PDO::FETCH_ASSOC);
            $mulheres = count($dados);

                  for ($i=0; $i < count($dados); $i++) { 
                
                    foreach ($dados[$i] as $key => $value) { 
                    $necessidade = $dados[$i]['NECESSIDADE'];
            }
        ?>
            <tr class="row-table">
                <td><span><?php echo $necessidade;?></span></td>
            </tr>
            <?php 
            } 
            ?>
        </table>
        <?php include('../view/returnPage.php');?>
    </div>
</body>
</html>