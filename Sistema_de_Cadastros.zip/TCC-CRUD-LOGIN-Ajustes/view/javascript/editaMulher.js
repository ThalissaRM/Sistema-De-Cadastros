var Side4 = document.querySelector('.side-04');
var OpenForm4 = document.querySelector('#openForm4');
var Background = document.querySelector('.overlay');
var ReturnButton = document.querySelector('.input-return');

OpenForm4.addEventListener('click', function() {
    Side4.style.display = 'block';
    Side4.style.zIndex = '2';
    Background.style.display = 'flex';
    ReturnButton.style.display = 'flex'
});

ReturnButton.addEventListener('click', function(){
    Side4.style.display = 'none';
    Background.style.display = 'none';
    ReturnButton.style.display = 'none';
    OpenForm.style.display = 'flex';
});

Background.addEventListener('click', function(){
    Side4.style.display = 'none';
    Background.style.display = 'none';
    ReturnButton.style.display = 'none';
});