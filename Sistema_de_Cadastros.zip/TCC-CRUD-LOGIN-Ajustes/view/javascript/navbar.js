var OpenMenu = document.querySelector('.icon-for-open-menu');
var OptionNav = document.querySelector('.options-nav-bar-1');
var Return = document.querySelector('.return');
var WidthPage = window.innerWidth || document.documentElement.clientWidth;

function ShowHide() {
  if (WidthPage >= 992 && OptionNav.style.display === '') {
    OptionNav.style.display = 'flex';
  } else {
    if (OptionNav.style.display === '') {
      OptionNav.style.display = 'flex';
    } else {
      OptionNav.style.display = '';
    }
  }
};

function updateWidthPage() {
  WidthPage = window.innerWidth || document.documentElement.clientWidth;
};

window.addEventListener('resize', function() {
  updateWidthPage();
  ShowHide();
});