var inputLocal = document.querySelector('#local-register');
var formLocal = document.querySelector('.cad-local-valid');
var inputPresence = document.querySelector('#presence-register');
var formPresence = document.querySelector('.cad-presence');
var inputNeeds = document.querySelector('#need-register');
var formNeeds = document.querySelector('.cad-needs');
var inputSecretary = document.querySelector('#secretary-register');
var formSecretary = document.querySelector('.cad-secretary');
var inputWork = document.querySelector('#work-register');
var formWork = document.querySelector('.cad-work');
var overlay = document.querySelector('.overlay');
var formInput = document.querySelector('.input-return');
var OpenForm = document.querySelector('#open-form');
var FormWoman = document.querySelector ('.cad-woman');

// Declaração das variáveis do formulário mult-step

var Form1 = document.querySelector('.form-1');
var Form2 = document.querySelector('.form-2');
var Form3 = document.querySelector('.form-3');
var Form4 = document.querySelector('.form-4');

var Next1 = document.querySelector('#Next-1');
var Next2 = document.querySelector('#Next-2');
var Prev1 = document.querySelector('#Prev-1');
var Prev2 = document.querySelector('#Prev-2');
var OpenDiv = document.querySelector('#select-checkbox');
var ReturnButton = document.querySelector('.return-button');
var OpenForm2 = document.querySelector('#open-cad-woman');

var Progress2 = document.getElementById("step-2");
var Progress3 = document.getElementById("step-3");


inputLocal.addEventListener('click', function() {
    if(formLocal.style.display === 'flex') {
        formLocal.style.display = 'none';
    } else {
        formLocal.style.display = 'flex';
        overlay.style.display = 'flex';
        formInput.style.display = 'flex';
    }
});

inputPresence.addEventListener('click', function() {
    if(formPresence.style.display === 'flex') {
        formPresence.style.display = 'none';
    } else {
        formPresence.style.display = 'flex';
        overlay.style.display = 'flex';
        formInput.style.display = 'flex';
    }
});

inputNeeds.addEventListener('click', function() {
    if(formNeeds.style.display === 'flex') {
        formNeeds.style.display = 'none';
    } else {
        formNeeds.style.display = 'flex';
        overlay.style.display = 'flex';
        formInput.style.display = 'flex';
    }
});

inputSecretary.addEventListener('click', function() {
    if(formSecretary.style.display === 'flex') {
        formSecretary.style.display = 'none';
    } else {
        formSecretary.style.display = 'flex';
        overlay.style.display = 'flex';
        formInput.style.display = 'flex';
    }
});

inputWork.addEventListener('click', function() {
    if(formWork.style.display === 'flex') {
        formWork.style.display = 'none';
    } else {
        formWork.style.display = 'flex';
        overlay.style.display = 'flex';
        formInput.style.display = 'flex';
    }
});

OpenForm.addEventListener('click', function() {
    EnableForm();
});

function EnableForm() {

    var WidthPage = window.innerWidth || document.documentElement.clientWidth;

    if (WidthPage >= 992 && WidthPage <= 1200) {
        FormWoman.style.display = 'block';
        FormWoman.style.position = 'fixed';
        FormWoman.style.left = '30%';
        FormWoman.style.top = '100px';
        FormWoman.style.zIndex = '2';
        overlay.style.display = 'flex';
        overlay.style.zIndex = '1';
        formInput.style.display = 'flex';
        Form4.style.display = 'none';
    } else if (WidthPage <= 992) {
        FormWoman.style.display = 'block';
        FormWoman.style.position = 'fixed';
        FormWoman.style.left = '10%';
        FormWoman.style.top = '100px';
        FormWoman.style.zIndex = '2';
        overlay.style.display = 'flex';
        overlay.style.zIndex = '1';
        formInput.style.display = 'flex';
        Form4.style.display = 'none';
    } else {
        FormWoman.style.display = 'block';
        FormWoman.style.position = 'fixed';
        FormWoman.style.left = '40%';
        FormWoman.style.top = '150px';
        FormWoman.style.zIndex = '2';
        overlay.style.display = 'flex';
        overlay.style.zIndex = '1';
        formInput.style.display = 'flex';
        Form4.style.display = 'none';
    }
};

function updateWidthPage() {
    WidthPage = window.innerWidth || document.documentElement.clientWidth;
  };

overlay.addEventListener('click', function() {
    formInput.style.display = 'none';
    formLocal.style.display = 'none';
    formNeeds.style.display = 'none';
    formPresence.style.display = 'none';
    formSecretary.style.display = 'none';
    formWork.style.display = 'none';
    FormWoman.style.display = 'none';
    overlay.style.display = 'none';
});

function returnPage() {

    var formReturn = document.querySelectorAll('.input-return');

    if(formLocal.style.display === 'flex' 
    || formPresence.style.display === 'flex' 
    || formNeeds.style.display === 'flex'
    || formSecretary.style.display === 'flex'
    || formWork.style.display === 'flex'
    || FormWoman.style.display === 'block')
    
    {
        formLocal.style.display = 'none';
        formPresence.style.display = 'none';
        formNeeds.style.display = 'none';
        formSecretary.style.display = 'none';
        formWork.style.display = 'none';
        FormWoman.style.display = 'none';
        formInput.style.display = 'none';
        overlay.style.display = 'none';
    }
};

// INÍCIO DO CÓDIGO DO FORMULÁRIO MULT-STEP

Next1.addEventListener('click', function() { 
    Form1.style.display = 'none';
    Form2.style.display = 'block';
    Progress2.classList.add('actived');
});

Next2.addEventListener('click', function() { 
    Form2.style.display = 'none';
    Form3.style.display = 'block';
    Progress3.classList.add('actived');
});

Prev1.addEventListener('click', function() { 
    Form2.style.display = 'none';
    Form1.style.display = 'block';
    Progress2.classList.remove('actived');
});

Prev2.addEventListener('click', function() { 
    Form3.style.display = 'none';
    Form2.style.display = 'block';
    Form4.style.display = 'none';
    Progress3.classList.remove('actived');
});

OpenDiv.addEventListener('click', function() {
    Form4.style.display = 'flex';
});

ReturnButton.addEventListener('click', function() {
    Form4.style.display = 'none';
});
