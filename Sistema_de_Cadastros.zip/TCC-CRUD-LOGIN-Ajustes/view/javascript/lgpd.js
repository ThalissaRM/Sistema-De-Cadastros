//variavel da url-- essa url teria que ser a do nosso site já estando num servidor. Site aleatorio como exemplo somente!!!
let lgpdUrl = 'https://jsonplaceholder.typicode.com/posts';


//variavel que contem o html do aviso de cookies
let lgpdHtml = `

<link rel="stylesheet" href="../view/css/lgpd.css">

<div class="lgpd">
    
<div class="lgpd--left">
Você concorda em fornecer seus dados pessoas para este site? E também concorda que não fará a distribuição ilegal ou venda dos dados? <br>
Para conferir detalhadamente todos os dados utilizados, leia a nossa <a href="../view/lgpd.html"> Política de Privacidade </a>
</div>

<div class="lgpd--right">
<button>SIM!</button>
</div>


</div>


`;





//armazenando registro usando o localstorage para armazenar o dados

//variavel que pega os dados do localstorage
let lsContent = localStorage.getItem('lgpd');

//verificar se não existe algum contéudo no registro

   if (!lsContent)
   {
    document.body.innerHTML += lgpdHtml;

    let lgpdArea = document.querySelector('.lgpd');
    let lgpdButton = lgpdArea.querySelector('button');

    //acao de click no botão OK
    lgpdButton.addEventListener('click',  async ()=>{
    
    //apos clicar no botão, a barra de cookies será removida
    lgpdArea.remove();


    //fazendo requisição para o servidor onde o site está hospedado salvar o ip, localização, navegador, data e horas que o usuario clicou no botão aceitando os termos. 

    //o usuario que clicou no ok, vai receber um tipo de codigozinho unico que o identifica, independente de estar logado ou não.

    //requisição pro back-end

    //url do back-end- era pra ser a url do nossoolhar site ja funcionando dentro de um servidor
    let result = await fetch(lgpdUrl);

    //resposta da identificação do usuario
    let json = await result.json();

    //verificação se não há presença de erros 
    if (json.error != '')
    {
    
    //não vai funcionar, pois não temos retorno de informação do back-end, então declaramos uma variavel
    let id = '123'; //codigo do usuario recebido pelo servidor depois que ele aperta no ok
       
    //fazendo com que depois que o botão seja clicado, a mensagem não apareça mais, pois verificou se voce tem conteudo registrado no localstorage.

    localStorage.setItem('lgpd', json.id); //aqui, no localstorage, deveria ser salvo o codigo identificador do usuario que apertou no ok e deu a permissão.
    }
    

    });

    /*o site precisa ficar responsavel por guardar a identificação de que aquele
    computador/usuario aceitou os termos. Clicar em ok significa gerar um codigo unico daquele usuario por exemplo num banco de dados.
    */




   }