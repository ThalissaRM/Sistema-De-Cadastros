var Form = document.querySelector('#form-presence');
var OpenPresenceForm = document.querySelector('.open-presence-form');
var OpenForm = document.querySelector('.open-presence-register');
var Background = document.querySelector('.overlay');
var ReturnButton = document.querySelector('.input-return');

OpenPresenceForm.addEventListener('click', function() {
    Form.style.display = 'flex';
    Form.style.zIndex = '2';
    Background.style.display = 'flex';
    OpenForm.style.display = 'none';
    ReturnButton.style.display = 'flex';
    ReturnButton.style.zIndex = '5';
});

ReturnButton.addEventListener('click', function(){
    Form.style.display = 'none';
    Background.style.display = 'none';
    ReturnButton.style.display = 'none';
    OpenForm.style.display = 'flex';
});

Background.addEventListener('click', function(){
    Form.style.display = 'none';
    Background.style.display = 'none';
    ReturnButton.style.display = 'none';
    OpenForm.style.display = 'flex';
});