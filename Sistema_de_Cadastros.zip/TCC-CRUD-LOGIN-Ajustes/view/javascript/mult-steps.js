var Form1 = document.querySelector('.form-1');
var Form2 = document.querySelector('.form-2');
var Form3 = document.querySelector('.form-3');
var Form4 = document.querySelector('.form-4');
var Overlay = document.querySelector('.bg-overlay');
var mainForm = document.querySelector('.cad-woman');
var mainImage = document.querySelector('.box-new-cad');

var Next1 = document.querySelector('#Next-1');
var Next2 = document.querySelector('#Next-2');
var Prev1 = document.querySelector('#Prev-1');
var Prev2 = document.querySelector('#Prev-2');
var OpenDiv = document.querySelector('#select-checkbox');
var ReturnButton = document.querySelector('.return-button');
var OpenFormWoman = document.querySelector('#open-cad-woman');

var Progress2 = document.getElementById("step-2");
var Progress3 = document.getElementById("step-3");

Next1.addEventListener('click', function() { 
    Form1.style.display = 'none';
    Form2.style.display = 'block';
    Progress2.classList.add('actived');
});

Next2.addEventListener('click', function() { 
    Form2.style.display = 'none';
    Form3.style.display = 'block';
    Progress3.classList.add('actived');
});

Prev1.addEventListener('click', function() { 
    Form2.style.display = 'none';
    Form1.style.display = 'block';
    Progress2.classList.remove('actived');
});

Prev2.addEventListener('click', function() { 
    Form3.style.display = 'none';
    Form2.style.display = 'block';
    Progress3.classList.remove('actived');
});

OpenFormWoman.addEventListener('click', function() {
    mainForm.style.display = 'block';
    mainImage.style.display = 'none';
});

OpenDiv.addEventListener('click', function() {
    Form4.style.display = 'flex';
    Overlay.style.display = 'block';
});

ReturnButton.addEventListener('click', function() {
    Form4.style.display = 'none';
    Overlay.style.display = 'none';
});

Overlay.addEventListener('click', function() {
    Form4.style.display = 'none';
    Overlay.style.display = 'none';
});