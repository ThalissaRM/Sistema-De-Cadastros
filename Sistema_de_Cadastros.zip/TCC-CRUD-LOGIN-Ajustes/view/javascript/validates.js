const patternFirst = /^[A-Za-zÁáÂâÃãÉéÈèÊêÍíÏïÓóÔôÕõÖöÚúÇçÑñ'\s]+$/; // Letras minusculas, maiusculas e acentuadas,espaços tbm sao aceitos

  /*^[A-ZÁÁÂÃÉÈÊÍÏÓÔÕÖÚÇÑ'\s]+[A-ZZÁÁÂÃÉÈÊÍÏÓÔÕÖÚÇÑ'\s]+$/;  /* letras maiusculas acentuadas apenas com um espaço*/ 

const patternSecond = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;     /*padrão de email*/ 
const patternThird =/^\([1-9]{2}\)[1-9]{4}-[1-9]{4,5}$/;  /*padrão de numero do celular*/                       
const patternFourth = /^\([1-9]{2}\)[1-9]{4}-[1-9]{4,5}$/; /* padrão de numero do telefone*/ 
const patternFifth = /^[0-9]/ ;  /* somente numeros*/       
const patternSixth =  /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[$*&@#])[0-9a-zA-Z$*&@#]+$/; /* Ao menos uma letra minuscula, maiuscula, um caracter especial e um numero*/
const selectField = document.getElementById("selectField");             
const field = document.querySelectorAll('.required');
const required = document.querySelectorAll('.span-message-required');
var span = document.querySelectorAll('.span-message');    

/*classes de: span, select , id de:  botões e inputs*/
/* se atentar aos links de cada pagina por conta dos campos que usa mascara jquery*/
/*se adicionar algum campo a mais ou tirar, vai ter que mexer nos indices dos "fields"(campos) */ 



/* FUNÇÃO PARA APARECER A MENSAGEM DE ERRO E MUDAR COR DA BORDA QUANDO O CAMPO NÃO TIVER COM OS REQUISITOS NECESSARIOS*/ 
function setError(page)
{
    field[page].style.border = '2px solid #B71C1C';
    span[page].style.display = 'flex';
}


/*FUNÇÃO PARA VOLTAR AO QUE ESTAVA  QUANDO O CAMPO CUMPRIR COM OS REQUISITOS*/ 
function removeError(page)
{
    field[page].style.border = '';  
    span[page].style.display = 'none';
}


/* TODOS ESSES VERIFY, VERIFICAM O TAMANHO DO CAMPO(ALGUNS NÃO) E EM SEGUIDA TESTA PARA VER SE O
CAMPO COM O INDICE N TEM O VALOR EQUIVALENTE A VARIAVEL CHAMADA PADRÃO(O VALOR DA VARIVEL FOI DEFINIDA
ACIMA COM UM REGEX)*/ 

/*AÓS VERIFICADO, SE O VALOR ATENDER AOS REQUISITOS ELE CHAMA OU A FUNÇÃO PARA SETAR ERRO, OU A FUNÇÃO PARA
REMOVER ERRO (AMBAS DEFINIDAS NAS LINHAS 30 E 38*/ 
/* ELE SABE ONDE MODIFICAR A COR DE CADA CAMPO POR CONTA DO INDICE () EM CADA FUNÇÃO*/ 


function verifyFirst() {
    if( field[0].value.length <= 3 || !patternFirst.test(field[0].value ) )
    {
        setError(0);
    }
    else
    {
        removeError(0);
    }
}      
function  verifySecond()
{
    if(field[1].value.length <= 3 || !patternSecond.test(field[1].value))
    {
        setError(1);
    }
    else
    {
        removeError(1);
    }
}
function verifyThird(){
    if(!patternFirst.test(field[2].value))
    {
        setError(2);
    }
    else
    {
        removeError(2);
    }
}
function verifyFourth(){
    if(!patternThird.test(field[3].value))
    {
        setError(3);
    }
    else
    {
        removeError(3);
    }
}
function verifyFifth(){
    if(!patternFourth.test(field[4].value))
    {
        setError(4);
    }
    else
    {
        removeError(4);
    }
}
function verifySixth(){
    if(field[2].value.length <= 3 || !patternFifth.test(field[2].value))
    {
        setError(2);
    }
    else
    {
        removeError(2);
    }
}

function verifySeventy(){
    if(field[3].value.length < 8 || !patternSixth.test(field[3].value))
    {
        setError(3);
    }
    else{
        removeError(3);
        comparePass(4); 
    }
}


/*FUNÇÃO PARA VERIFICAR SE AMBAS AS SENHAS DIGITADAS SÃO IGUAIS*/ 
function comparePass(){
    if(field[3].value == field[4].value){
        removeError(4); 
    }
    else{
        setError(4);   
    }
} 

function verifyEighteen(){
    if(field[1].value.length < 8 || !patternFirst.test(field[1].value))
    {
        setError(1);
    }
    else{
        removeError(1); 
    }
}



/*MASCARA JQUERY PARA CELULAR*/ 
    $("#celular").keypress(function() {
    $(this).mask('(00)0000-00009')
    }); 
    
    
    /*MASCARA JQUERY PARA TELEFONE*/
    $("#telefone").keypress(function() {
    $(this).mask('(00)0000-0000')
    });
    
    /*MASCARA JQUERY PARA O NUMERO DE REGISTRO*/
    $("#numRegistro").keypress(function() {
    $(this).mask('999999')
    });

/*ARMAZENAR OS DADOS PREENCHIDOS POR SESSÃO (QUANDO FECHA A GUIA OS DADOS SE PERDEM)*/
// sessionStorage.setItem(field[0,1,2,3,4,5]);
// const teste = sessionStorage.getItem(field[0,1,2,3,4,5]); 


