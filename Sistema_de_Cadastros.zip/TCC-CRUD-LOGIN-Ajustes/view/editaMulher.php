<?php
    require_once '../model/conn.php';
    $con = new Conexao("nossoolhar", "localhost", "root", "");
    session_start();
    if(empty($_SESSION['idAcessoUsuario']) || ($_SESSION['idAcessoUsuario'] != '1') && ($_SESSION['idAcessoUsuario'] != '2')  && ($_SESSION['idAcessoUsuario'] != '3')){
        session_destroy();
        header('Location: ../view/index.html');
        exit();
    }
    $_SESSION['returnPage'] = $_SERVER['HTTP_REFERER'];
    if (isset($_GET['codmulher_up'])) {
        $codmulher_update = addslashes($_GET['codmulher_up']);
        $res= $con->buscarDadosMulher($codmulher_update);
        $res_nm= $con->buscarDadosMulher($codmulher_update);
    }
    if(isset($_POST['txtNomeMulher'])){
        $codm = addslashes($_GET['codmulher_up']);
        $nomeMulher= addslashes($_POST['txtNomeMulher']);
        $bairro= addslashes($_POST['txtBairro']);
        $emailMulher=addslashes ($_POST['txtEmailMulher']);
        $celular=addslashes ($_POST['txtCelular']);
        $telefone=addslashes ($_POST['txtTelefone']);
        $dataNasc=addslashes ($_POST ['txtDataNasc']);
        $local= $_POST ['selectLocal'];
        $funcionario= $_POST ['selectFuncionario'];
        $countException = false;
        $regexTexto = "/^[A-Za-zÁáÂâÃãÉéÈèÊêÍíÏïÓóÔôÕõÖöÚúÇçÑñ'\s]+$/" ; 
        $regexNumero ='/^\(\d{2}\)\d{4}-\d{4,5}$/';
        $campos = array(
            'txtNomeMulher' => 'required | leng | texto', 
            'txtBairro' => 'required | leng | texto',
            'txtEmailMulher' => 'required |leng | email', 
            'txtCelular' => 'required | numero',
            'txtTelefone' => 'required | numero',  
            'txtDataNasc' => 'required | lengdata', 
            'selectLocal' => 'required ', 
            'selectFuncionario' => ' required', 
        );
        foreach ($campos as $field => $value) 
        {
            try 
            {
                if (strpos($value, 'required') !== false) 
                {
                    if(empty($_POST[$field]) || !isset($_POST[$field]))
                        {
                            throw new Exception;
                        }
                }
                if (strpos($value, 'email') !== false)
                {
                    if( !filter_var ($_POST[$field], FILTER_VALIDATE_EMAIL))
                        {
                            throw new Exception;
                        }
                }
                if (strpos($value, 'leng') !== false) 
                    {
                    if ((strlen(trim($_POST[$field])) <= 3)) 
                        {
                            throw new Exception;  
                        }   
                    }       
                if (strpos($value, 'numero') !== false) 
                {
                    if ((strlen(trim($_POST[$field])) <= 12) || (strlen(trim($_POST[$field])) >= 17)) 
                        {
                            throw new Exception; 
                        }       
                }      
                if(strpos($value, 'numero') !== false)
                {
                     if(!preg_match($regexNumero, ($_POST[$field]) ))
                    {
                        throw new Exception;
                    }
                }
                if(strpos($value, 'texto'))
                {
                    if (!preg_match($regexTexto, ($_POST[$field]) )) 
                    {
                        throw new Exception;
                    }
                } 
            } 
            catch (Exception $e) 
            {
                echo $e->getMessage();
                $countException = true; 
            }
        }
        if(!$countException)
        {  
            echo "
            <script>alert('Dados atualizados com sucesso!')</script>
            <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/consultaMulher.php'>
              ";
            $con->atualizarDadosMulher($codm, $nomeMulher, $bairro, $emailMulher, $celular, $telefone, $dataNasc, $local, $funcionario);
        }
        else{
            echo "
            <script>alert('Preencha todos os campos corretamente!')</script>
            <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/editaMulher.php'>
              ";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../view/images/logo_franco.jpg" type="image/jpg">
    <link rel="stylesheet" href="../view/css/returnPage.css">
    <link rel="stylesheet" href="../view/css/reset.css">
    <link rel="stylesheet" href="../view/css/style.css">
    <script defer src="../view/javascript/editaMulher.js"></script>
    <script defer src="../view/javascript/validates.js"></script>
    <script defer src="../view/javascript/navbar.js"></script>  
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    <script src="https://kit.fontawesome.com/0e0aebece5.js" crossorigin="anonymous"></script>
    <title>Nosso Olhar | Editar Dados da Mulher</title>
</head>
<body class="edit-page">
    <div class="overlay">
    </div>
    <div class="input-return" onclick="returnPage()">
        <i class="fa-solid fa-xmark"></i>
        <input id="input-set-return" onclick="returnPage()" type="submit" value="">
    </div>
    <?php
        include('../view/header.php')
    ?>
    <main class="edit-page">
        <div class="edit-woman">
            <h3>ATUALIZAR DADOS</h3>
            <form id="edit-woman" method="POST">
                <div class="side-01">
                    <div class="box-woman">
                        <span>NOME COMPLETO</span>
                        <input type="text" name="txtNomeMulher" minlength="3" required value="<?php if (isset($res)) {echo $res['NOME'];}?> ">
                    </div>
                    <div class="box-woman">
                        <span>DATA DE NASCIMENTO</span>
                        <input type="date" name="txtDataNasc" size="40px" required value="<?php if (isset($res)) {echo $res['DTNASC'];}?>">
                    </div>
                    <div class="box-woman">
                        <span>ENDEREÇO</span>
                        <input type="text" name="txtBairro" minlenght="3" required placeholder="Bairro:" size="40px" value="<?php if (isset($res)) {echo $res['BAIRRO'];}?>">
                    </div>
                </div>
                <div class="side-02">
                    <div class="box-woman">
                        <span>E-MAIL</span>
                        <input type="email" name="txtEmailMulher" minlenght="3" required placeholder="E-mail:" size="40px" value="<?php if (isset($res)) {echo $res['EMAIL'];}?>">
                    </div>
                    <div class="box-woman">
                        <span>CELULAR</span>
                        <input type="text" id="celular" name="txtCelular"minlenght="3" required placeholder="(11) 99999-9999:" size="40px" value="<?php if (isset($res)) {echo $res['CEL'];}?>">
                    </div>
                    <div class="box-woman">
                        <span>TELEFONE</span>
                        <input type="text" id="telefone" name="txtTelefone" minlenght="3" required placeholder="(11) 4444-4444:" size="40px" value="<?php if (isset($res)) {echo $res['TEL'];}?>">
                    </div>
                </div>
                <div class="side-03">
                    <div class="box-woman">
                        <span>LOCAL</span>
                        <select name="selectLocal" required>
                            <option value="">Clique para selecionar</option>
                            <?php
                                require_once '../model/conn.php';  
                                $con = new Conexao("nossoolhar","localhost","root",""); 
                                $select = "SELECT * FROM LOCALCADASTRO  WHERE APARECER LIKE '1' ";
                                $param = $con->query($select);
                                while ($select = $param->fetch(PDO::FETCH_ASSOC)){
                                    ?>
 
                                    <option value="<?php echo $select['CODLOCALCADASTRO'];?>"  <?php echo $res ['CODLOCALCADASTRO'] == $select['CODLOCALCADASTRO'] ? 'selected' : '';?>>
                                    <?php echo $select ['NOMELOCAL'];?>
 
                                     </option>
                         <?php
                                 }
                             ?>
                         </select>
                    </div>
                    <div class="box-woman">
                        <span>FUNCIONÁRIO</span>
                        <select name="selectFuncionario" required>
                            <option value="">Clique para selecionar</option>
                            <?php
                                require_once '../model/conn.php';  
                                $con = new Conexao("nossoolhar","localhost","root",""); 
                                $select = "SELECT * FROM CADUSUARIO WHERE APARECER LIKE '1'";
                                $param = $con->query($select);
                                while ($select = $param->fetch(PDO::FETCH_ASSOC)){
                                    ?>
 
                                    <option value="<?php echo $select['NUMREGISTRO'];?>"  <?php echo $res ['NUMREGISTROM'] == $select['NUMREGISTRO'] ? 'selected' : '';?>>
                                    <?php echo $select ['NOME_FUNCIONARIO'];?>
 
                                     </option>
                         <?php
                                 }
                             ?>
                         </select>
                    </div>
                    <div class="box-woman">
                        <span>NECESSIDADES</span>
                        <input id="openForm4" type="button" value="Clique para selecionar">   
                    </div>
                </div>
                <div class="side-04">
                    <div class="forms-of-checkbox-items-edit-woman box-woman">
                    <span>Não é possível editar este campo</span>
                        <?php
                            // require_once '../model/conn.php';  
                            // $con = new Conexao("nossoolhar","localhost","root",""); 
                            // $checked = "SELECT * FROM necessidade";
                            // $param = $con->query($checked);
                            // while ($result = $param->fetch(PDO::FETCH_ASSOC)) {
                            // echo '<input class="checkbox-items-edit-woman" type="checkbox" name="necessidades[]" value="' .$result["CODNECESSIDADE"]. '">';
                            // echo $result ["NECESSIDADE"];
                            // echo '</label><br>';
                            // }
                        ?>
                    </div>
                </div>
                <div class="side-05">
                    <div class="box-woman">
                        <input type="submit" value="Atualizar dados">
                    </div>
                </div>
            </form>
        </div>
        <?php include('../view/returnPage.php');?>
    </main>    
</body>
</html>