<?php
    require_once '../model/conn.php';
    $con = new Conexao("nossoolhar", "localhost", "root", "");
    $_SESSION['returnPage'] = $_SERVER['HTTP_REFERER'];
    session_start();
    if(empty($_SESSION['idAcessoUsuario']) || ($_SESSION['idAcessoUsuario'] != '1')){
        session_destroy();
        header('Location: ../view/index.html');
        exit();
    }
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../view/images/logo_franco.jpg" type="image/jpg">
    <link rel="stylesheet" href="../view/css/returnPage.css">
    <link rel="stylesheet" href="../view/css/reset.css">
    <link rel="stylesheet" href="../view/css/style.css">
    <script defer src="../view/javascript/navbar.js"></script>
    <script defer src="../view/javascript/scripts.js"></script>
    <script src="https://kit.fontawesome.com/0e0aebece5.js" crossorigin="anonymous"></script>
    <title>Nosso Olhar | Funcionários</title>
</head>
<body class="search-page">
    <?php
        switch ($_SESSION['idAcessoUsuario']) {
            case '2':
                header('location: ../view/cadastros.php');
                break;

            case '3':
                header('location: ../view/cadastraMulher.php');
                break;
            
            case '4':
                header('location: ../view/registraPresenca.php');
                break;
        }
    ?>
    <?php
        include ('../view/header.php');
    ?>
    <div class="container-for-tables">
        <?php
            if (isset($_GET['funcionario'])) {
            $numregistro = addslashes($_GET['funcionario']);
            $con->excluirFuncionario($numregistro);
            header("location: consultaFuncionario.php");
            }
        ?>
        <div class="search-bar">
            <form class="search-box">
                <input type="search" aria-label="Search" placeholder="Pesquisar..." name="txtbuscar">
                <button type="submit" name="buscar"><i class="fa-solid fa-magnifying-glass"></i></button>
            </form>
        </div>
        <table class="table-style">
            <tr class="title-table">
                <td class="title-table" colspan="6">Funcionários cadastrados</td>
            </tr>
            <tr class="title-table">
                <td class="title-table">Nº do Registro</td>
                <td class="title-table">Nivel de acesso</td>
                <td class="title-table">Nome</td>
                <td class="title-table">E-mail</td>
                <td class="title-table">Senha</td>
                <td class="title-table">Ações</td>
            </tr>

            <?php
                if(isset($_GET['buscar']) and $_GET['txtbuscar'] != '')
                {
                    $nome_buscar = $_GET['txtbuscar'] . '%';
                    $res = $con->query("SELECT * FROM CADUSUARIO WHERE NOME_FUNCIONARIO LIKE '$nome_buscar' OR EMAIL_FUNCIONARIO LIKE '$nome_buscar' AND APARECER LIKE '1'");
                }else{
                    $res = $con->query("SELECT * FROM CADUSUARIO  WHERE APARECER LIKE '1' ORDER BY NOME_FUNCIONARIO ASC");
                } 

                $dados = $res->fetchAll(PDO::FETCH_ASSOC);

                $funcionarios = count($dados);
                for ($i=0; $i < count($dados); $i++) {
                    foreach ($dados[$i] as $key => $value) {
                    $numregistro = $dados[$i]['NUMREGISTRO'];
                    $nivel = $dados[$i]['NIVEL_ACESSO'];
                    $nome = $dados[$i]['NOME_FUNCIONARIO'];
                    $email = $dados[$i]['EMAIL_FUNCIONARIO'];
                    $senha = $dados[$i]['SENHA'];
                }
            ?>
            <tr class="row-table">
                <td><?php echo $numregistro; ?></td>
                
                <td>
                    <?php 
                    if ($nivel==1) {
                        echo "ADMINISTRADOR";
                    }

                    else if ($nivel==2)
                    {
                        echo "MODERADOR";
                    }

                    else if ($nivel==3)
                    {
                        echo "FUNCIONÁRIO";
                    }

                    else if ($nivel==4)
                    {
                        echo "INFORME";

                    }



                     ?>
                     </td>



                <td><?php echo $nome; ?></td>
                <td><?php echo $email; ?></td>
                <td><?php echo $senha; ?></td>
                <td class="icon-column">
                    <a href="editaFuncionario.php?numregistro_up=<?php echo $dados [$i] ['NUMREGISTRO'] ?>"><i class="fa-solid fa-pencil"></i></a>
                    <a href="consultaFuncionario.php?funcionario=<?php echo $dados [$i] ['NUMREGISTRO'] ?>" onclick="return confirm('Deseja realmente excluir?')" ><i class="fa-solid fa-trash"></i></a>
                </td>
            </tr>
            <?php } ?>
        </table>
        <?php include('../view/returnPage.php');?>
    </div>

</body>
</html>