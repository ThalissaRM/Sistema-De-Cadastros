<?php    
    require_once '../model/conn.php';
    $con = new Conexao("nossoolhar", "localhost", "root", "");
    session_start();
    if(empty($_SESSION['idAcessoUsuario']) || ($_SESSION['idAcessoUsuario'] != '1') && ($_SESSION['idAcessoUsuario'] != '2')){
        session_destroy();
        header('Location: ../view/index.html');
        exit();
    }
    $_SESSION['returnPage'] = $_SERVER['HTTP_REFERER'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../view/images/logo_franco.jpg" type="image/jpg">
    <link rel="stylesheet" href="../view/css/returnPage.css">
    <link rel="stylesheet" href="../view/css/reset.css">
    <link rel="stylesheet" href="../view/css/style.css">
    <script defer src="../view/javascript/navbar.js"></script>
    <script defer src="../view/javascript/scripts.js"></script>
    <script src="https://kit.fontawesome.com/0e0aebece5.js" crossorigin="anonymous"></script>
    <title>Nosso Olhar | Dashboard</title>
</head>
<body>
    <?php
        include('../view/header.php');
    ?>
    <main class="relatory-page">
        <iframe title="Relatório_Projeto_NossoOlhar - Página 1" width="1024" height="612" src="https://app.powerbi.com/reportEmbed?reportId=499fb8cb-c855-45cf-86fe-ed16f407ba6a&autoAuth=true&ctid=ed38466c-b641-437d-9ae9-d801b829fa94" frameborder="0" allowFullScreen="true"></iframe>
    <?php
        include('../view/returnPage.php');
    ?>
    </main>
    </body>
</html>