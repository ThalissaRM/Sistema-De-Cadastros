<?php
    require_once '../model/conn.php';
    $con = new Conexao("nossoolhar", "localhost", "root", "");
    session_start();
    if(empty($_SESSION['idAcessoUsuario']) || ($_SESSION['idAcessoUsuario'] != '3')){
        session_destroy();
        header('Location: ../view/index.html');
        exit();
    }
    $_SESSION['returnPage'] = $_SERVER['HTTP_REFERER'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <link rel="shortcut icon" href="../view/images/logo_franco.jpg" type="image/jpg">
    <link rel="stylesheet" href="../view/css/returnPage.css">
    <link rel="stylesheet" href="../view/css/reset.css">
    <link rel="stylesheet" href="../view/css/style.css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    <script defer src="../view/javascript/validates.js"></script>
    <script defer src="../view/javascript/mult-steps.js"></script>
    <script src="https://kit.fontawesome.com/0e0aebece5.js" crossorigin="anonymous"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nosso Olhar | Cadastrar nova mulher</title>
</head>
<body>
    <?php
        include ('../view/header.php');
    ?>
    <main>
        <div class="bg-overlay">            
        </div>
        <div class="container-cad-woman">
            <div class="box-new-cad">
                <div class="gradient-box">
                    <div class="image-box">
                        <img src="../view/images/undraw_articles_wbpb.svg" alt="">
                    </div>
                </div>
                <div class="button-cad-form">
                    <input id="open-cad-woman" type="button" value="REALIZAR NOVO CADASTRO">
                </div>
            </div>
            <div class="cad-woman">
                <form method="POST" action="../controller/validaMulher.php">
                    <div class="form-1" id="form-1">
                        <h3>INFORMAÇÕES PRINCIPAIS</h3>
                        <div class="box-form">
                            <span>NOME COMPLETO</span>
                            <input required="required" type="text" name="txtNomeMulher"  minlength="3">
                        </div>
                        <div class="box-form">
                            <span>DATA DE NASCIMENTO</span>
                            <input required="required" type="date" name="data">
                        </div>
                        <div class="box-form">
                            <span>ENDEREÇO</span>
                            <input required="required" type="text" name="txtBairro" minlength="3">
                        </div>
                        <div class="btn-box next">
                            <input required="required" type="button" value="Próximo"  id="Next-1">
                        </div>
                    </div> 
                    <div class="form-2" id="form-2">
                        <h3>CONTATO</h3>
                        <div class="box-form">
                            <span>E-MAIL</span>
                            <input required="required" type="email" name="txtEmailMulher" minlength="3">
                        </div>
                        <div class="box-form">
                            <span>CELULAR</span>
                            <input required="required" id="celular" type="tel" name="txtCelular" placeholder="(DDD) 9 9999-9999">
                        </div>
                        <div class="box-form">
                            <span>TELEFONE</span>
                            <input required="required" id="telefone" type="text" name="txtTelefone" placeholder="(DDD) 4444-4444">
                        </div>
                        <div class="btn-box next">
                            <input required="required" type="button" value="Próximo" id="Next-2">
                        </div>
                        <div class="btn-box prev">
                            <input required="required" type="button" value="Voltar" id="Prev-1">
                        </div>
                    </div> 
                    <div class="form-3" id="form-3">
                        <h3>FINALIZAÇÃO DE CADASTRO</h3>
                        <div class="box-form">
                            <span>LOCAL</span>
                            <select name="selectLocal">
                            <option>Selecione o local</option>
                            <?php
                                require_once '../model/conn.php';  
                                $con = new Conexao("nossoolhar","localhost","root",""); 
                                $select = "SELECT * FROM LOCALCADASTRO WHERE APARECER LIKE '1'";
                                $param = $con->query($select);
                                while ($select = $param->fetch(PDO::FETCH_ASSOC)){
                                echo '<option value="'.$select["CODLOCALCADASTRO"]. '">';           
                                    echo $select ["NOMELOCAL"];        
                                }    
                            ?>
                            </select>
                        </div>
                        <div class="box-form">
                            <span>FUNCIONÁRIO</span>
                            <select name="selectFuncionario">
                                <option>Selecione o funcionário</option>
                            <?php
                                require_once '../model/conn.php';  
                                $con = new Conexao("nossoolhar","localhost","root",""); 
                                $select = "SELECT * FROM CADUSUARIO WHERE APARECER LIKE '1' AND NUMREGISTRO ='". $_SESSION['idAcesso']."'";
                                $param = $con->query($select);
                                while ($select = $param->fetch(PDO::FETCH_ASSOC)){
                                    echo '<option value="'.$select["NUMREGISTRO"]. '">';
                                    echo $select ["NOME_FUNCIONARIO"];
                                }
                            ?>
                            </select>
                        </div>
                        <div class="box-form checkbox-items">
                            <span>NECESSIDADES</span>
                            <input required="required" id="select-checkbox" type="button" value="Clique para selecionar...">
                        </div>
                        <div class="btn-box prev">
                            <input required="required" type="button" value="Voltar" id="Prev-2">
                        </div>
                        <div class="btn-box next">
                            <input required="required" type="submit" value="Cadastrar">
                        </div>
                    </div>
                    <div class="form-4">
                        <h3>SELECIONAR NECESSIDADES</h3>
                        <div class="box-form">
                            <?php
                                require_once '../model/conn.php';  
                                $con = new Conexao("nossoolhar","localhost","root",""); 
                                $checked = "SELECT * FROM necessidade WHERE APARECER LIKE '1'";
                                $param = $con->query($checked);
                                while ($result = $param->fetch(PDO::FETCH_ASSOC)) {
                                    echo '<input class="checkbox-items" type="checkbox" name="necessidades[]" value="' .$result["CODNECESSIDADE"]. '">';
                                    echo $result ["NECESSIDADE"];
                                    echo '<p>';
                                }
                            ?>
                        </div>
                        <div class="return-button">
                            <i class="fa-solid fa-arrow-left"></i>
                        </div>
                    </div>
                </form>
            <div class="progress-bar">
                <div class="step actived" id="step-1"><span>1</span></div>
                <div class="step" id="step-2"><span>2</span></div>
                <div class="step" id="step-3"><span>3</span></div>                    
            </div>
        </div>
    </main>  
    <script src="javascript/lgpd.js">


</script>  
</body>
</html>