<?php

    Class Conexao
    {
        // MÉTODO CONSTRUTOR PARA ABRIR E TESTAR CONEXÃO COM BANCO
        private $pdo;
        public function __construct ($nossoolhar, $host, $user, $senha)
        { 
            try{
                $this->pdo = new PDO("mysql:dbname=".$nossoolhar.";host=".$host,$user,$senha);
             //   echo "conexao realizada com sucesso<br>"; 
            }
            catch(PDOException $e){
                echo "ERRO DE CONEXAO NO PDO:" .$e->getMessage();
                exit();
            }
            catch (Exception $e){
                echo "Erro generico: " .$e->getMessage();;
                }
        }     
        public function query($sql) {
            return $this->pdo->query($sql);
        }

        /// FUNÇÃO PARA VALIDAR SE O USUÁRIO JA EXISTE ATRAVÉS DO NUMERO DE REGISTRO (SE NÃO EXISTIR CHAMA OUTRA FUNÇÃO)
        public function valida($NumRegistro,$CodNivel,$NomeFuncionario,$Email,$Senha)
        {
            $teste = $this->pdo->prepare("select numregistro, email_funcionario from cadusuario where numregistro = :numregistro or email_funcionario = :email");
            $teste->bindValue(":numregistro", $NumRegistro);
            $teste->bindValue(":email", $Email);
            $teste->execute();
            if($teste->rowCount()>0){
                echo "
                <script>alert('Funcionário Já Existe!')</script>
                <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/cadastros.php'>
                  ";
           
            }
            
            else{
            $this->insereCampo($NumRegistro,$CodNivel,$NomeFuncionario,$Email,$Senha);
                  echo"
                  <script>alert('cadastrado com sucesso')</script>
                  <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/cadastros.php'>
                  ";
            }
          }

        /// FUNÇÃO PARA INSERIR DADOS CASO O USUÁRIO NÃO TENHA CADASTRO
        public function insereCampo($NumRegistro,$CodNivel,$NomeFuncionario,$Email,$Senha)
        {
            $insereUser = $this->pdo->prepare("insert into cadusuario(numregistro, nivel_acesso, nome_funcionario, email_funcionario, senha, aparecer) 
            values (:numregistro, :nivel_acesso, :nome_funcionario, :email_funcionario, :senha, true)");
            $insereUser->bindValue(":numregistro", $NumRegistro);
            $insereUser->bindValue(":nivel_acesso", $CodNivel);
            $insereUser->bindValue(":nome_funcionario", $NomeFuncionario);
            $insereUser->bindValue(":email_funcionario", $Email);
            $insereUser->bindValue(":senha", $Senha);

            // ATRIBUI O VALOR 1,2,3,4 DE ACORDO COM O VALUE DO OPTION LOCALIZADO NO CADFUNCIONARIO
            // SERVE PARA DEFINIR O NÍVEL DE ACESSO DO USUÁRIO
            if($CodNivel == 'adm'){
                $insereUser->bindValue(":nivel_acesso",'1');
            }
            else if($CodNivel == 'mod'){
                $insereUser->bindValue(":nivel_acesso", '2');
            }
            else if($CodNivel == 'func'){
                $insereUser->bindValue(":nivel_acesso", '3');
            }
            else if($CodNivel == 'info'){
                $insereUser->bindValue(":nivel_acesso", '4');
            }

            $insereUser->execute();
        }

        ///VERIFICA SE JÁ EXISTE O SERVIÇO ATRAVÉS DO NOME
        public function validaServico($txtNomeServico,$txtObjetivo)
        {
            $teste = $this->pdo->prepare("select codservico from servico where nomeservico = :nomeservico");
            $teste->bindValue(":nomeservico", $txtNomeServico);
            $teste->execute();
            if($teste->rowCount()>0){
               echo "
               <script>alert('Serviço ja Cadastrado!')</script>
               <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/cadastros.php'>
             ";
            }
        /// SE NÃO, CHAMA FUNÇÃO PARA INSERIR DADOS
            else{
            $this->insereServico($txtNomeServico,$txtObjetivo);
            session_start();
            if ($_SESSION['idAcessoUsuario'] == 1 || $_SESSION['idAcessoUsuario'] == 2 ){
                echo"
                <script>alert('Serviço cadastrado com sucesso')</script>
                <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/cadastros.php'>";
            }
            else{
                echo"
                <script>alert('Serviço cadastrado com sucesso')</script>
                <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/registraPresenca.php'>";
            }
            }
          }

        ///FUNÇÃO PARA INSERIR DADOS NO SERVIÇO
          public function insereServico($txtNomeServico,$txtObjetivo)
          {
              $insereSer = $this->pdo->prepare("insert into servico(nomeservico, objetivo, aparecer) 
              values (:nomeservico, :objetivo, true)");
              $insereSer->bindValue(":nomeservico",$txtNomeServico);
              $insereSer->bindValue(":objetivo", $txtObjetivo);
              $insereSer->execute();
          }

        ///VERIFICA SE JÁ EXISTE SECRETARIA ATRAVÉS DO NOME
          public function validaSecretaria($secretarias, $servicosSelecionados)
          {
              $teste = $this->pdo->prepare("select nomesecretaria from secretaria where nomesecretaria = :nomesecretaria");
              $teste->bindValue(":nomesecretaria", $secretarias);
              $teste->execute();
              if($teste->rowCount()>0){
               echo "
               <script>alert('Secretaria já cadastrada')</script>
               <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/cadastros.php'>
             ";
              }

        /// SE NÃO, CHAMA FUNÇÃO PARA INSERIR DADOS
              else{
              $this->insereSecretaria($secretarias, $servicosSelecionados);
                echo" 
                <script>alert('cadastrado com sucesso')</script>
                <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/cadastros.php'>
                   ";
              }
            }

        ///FUNÇÃO PARA INSERIR DADOS
         public function insereSecretaria($secretarias, $servicosSelecionados)
            {
                $insereSer = $this->pdo->prepare("insert into secretaria(nomesecretaria,aparecer)    
                values (:nomesecretaria, true)"); 
                $insereSer->bindValue(":nomesecretaria",$secretarias); 
                $insereSer->execute();

                $codsecretaria = $this->pdo->lastInsertId();
                foreach($servicosSelecionados as $codservico) {

                $insereSerdois = $this->pdo->prepare("insert into servico_secretaria(codservico, codsecretaria_ss,aparecer) 
                values (:codservico, :codsecretaria,true)");
                $insereSerdois->bindValue(":codservico",$codservico);
                $insereSerdois->bindValue(":codsecretaria",$codsecretaria);
                $insereSerdois->execute();
                }
            }

        ///VERIFICA SE JÁ EXISTE LOCAL ATRAVÉS DO NOME
            public function validaLocal($txtLocal){
                $teste = $this->pdo->prepare("select codlocalcadastro from localcadastro where codlocalcadastro = :codlocalcadastro");
                $teste->bindValue(":codlocalcadastro", $txtLocal);
                $teste->execute();
                if($teste->rowCount()>0){
                    echo "
                    <script>alert('Local já cadastrado')</script>
                    <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/cadastros.php'>
                    ";
            }
        // SE NÃO, CHAMA FUNÇÃO PARA INSERIR DADOS 
            else{
            $this->insereLocal($txtLocal);  
                  echo"
                  <script>alert('Local cadastrado com sucesso')</script>
                  <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/cadastros.php'>";
            }
          }

        //FUNÇÃO PARA INSERIR DADOS NO LOCAL
          public function insereLocal($txtLocal)
          {
              $insere = $this->pdo->prepare("insert into localcadastro(nomelocal,aparecer) values (:nomelocal,true)");
              $insere->bindValue(":nomelocal",$txtLocal);
              $insere->execute();
          }

        
        ///VERIFICA SE JÁ EXISTE NECESSIDADE ATRAVÉS DO NOME
          public function validaNecessidade($txtNecessidade){
            $teste = $this->pdo->prepare("select necessidade from necessidade where necessidade  = :necessidade");
            $teste->bindValue(":necessidade", $txtNecessidade);
            $teste->execute();
            if($teste->rowCount()>0){
                echo"
                <script>alert('Necessidade já cadastrada!')</script>
                <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/cadastros.php'>";
          }

          /// SE NÃO, CHAMA FUNÇÃO PARA INSERIR DADOS
            else{
            $this->insereNecessidade($txtNecessidade);
                echo"
                <script>alert('Necessidade cadastrada com sucesso')</script>
                <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/cadastros.php'>";
            }
        }  
        ///FUNÇÃO PARA INSERIR A NECESSIDADE   (COLOCAR ALI EM CIMA DPS)  <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/cadNecessidade.php'>
              
        public function insereNecessidade($txtNecessidade)
        {
            $insere = $this->pdo->prepare("insert into necessidade(necessidade, aparecer) values (:necessidade, true)");
            $insere->bindValue(":necessidade",$txtNecessidade);
            $insere->execute();
        }

        /// VERIFICA SE JA EXISTE CADASTRO DA MULHER PELO EMAIL
        public function validaMulher($nomeMulher,$bairro,$emailMulher,$celular,$telefone,$dataNasc,$local,$funcionario,$necessidadesSelecionadas){
            $teste = $this->pdo->prepare("select email from mulher where email = :email");
              $teste->bindValue(":email", $emailMulher);
              $teste->execute();

              if($teste->rowCount()>0){
                
                echo"Mulher já cadastrada!";
                  
              }
        ///SE NÃO, CHAMA FUNÇÃO PARA INSERIR DADOS
              else{
              $this->insereMulher($nomeMulher,$bairro,$emailMulher,$celular,$telefone,$dataNasc,$local,$funcionario,$necessidadesSelecionadas);
            
            //  ACRESCENTADO DAQUI PRA BAIXO 
              session_start();
                if ($_SESSION['idAcessoUsuario'] == 1 || $_SESSION['idAcessoUsuario'] == 2 ){
                    echo"
                    <script>alert('Mulher cadastrada com sucesso')</script>
                    <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/cadastros.php'>";
                }
                else{
                    echo"
                    <script>alert('Mulher cadastrada com sucesso')</script>
                    <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/cadastraMulher.php'>";
                }

            }
            }
            ///  <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/cadMulher.php'>         >>>voltar isso pro insere mulher


        /// FUNÇÃO PARA INSERIR DADOS DA MULHER
        public function insereMulher($nomeMulher,$bairro,$emailMulher,$celular,$telefone,$dataNasc,$local,$funcionario,$necessidadesSelecionadas){
            $insere = $this->pdo->prepare("insert into mulher(nome, bairro, email, cel, tel, dtnasc, codlocalcadastro, numregistrom, aparecer) 
            VALUES (:nome,:bairro,:email,:cel,:tel,:dtnasc,:localcadastro,:numregistro, true)");
            $insere->bindValue(":nome",$nomeMulher);
            $insere->bindValue(":bairro",$bairro);
            $insere->bindValue(":email",$emailMulher);
            $insere->bindValue(":cel",$celular);
            $insere->bindValue(":tel",$telefone);
            $insere->bindValue(":dtnasc",$dataNasc);
            $insere->bindValue(":localcadastro",$local);
            $insere->bindValue(":numregistro",$funcionario);
            $insere->execute();

            /// RECUPERA O CODIGO QUE ACABOU DE SER CRIADO PARA INSERIR NA TABELA RELACIONAL NECESSIDADE MULHER
            $codMulher = $this->pdo->lastInsertId();
            
            //PROCURA TODAS AS NECESSIDADES SELECIONADAS E ASSOCIA COM A CHAVE PRIMARIA DA TABELA NECESSIDADE
            foreach($necessidadesSelecionadas as $CODNECESSIDADE){
            $insereNecDois = $this->pdo->prepare("insert into necessidademulher(codmulher_n, codnecessidade)values(:codmulher, :codnecessidade)");
            $insereNecDois->bindValue(":codmulher", $codMulher);
            $insereNecDois->bindValue(":codnecessidade",$CODNECESSIDADE);
            $insereNecDois->execute();   
            }


        }


        public function insereInforme($dtcomparecimento,$hrinicio,$hrtermino,$selfuncionario,$selservicosecretaria,$selsituacao,$selmulher){
            $insere = $this->pdo->prepare("insert into informe(datacomparecimento, hrinicio, hrtermino, numregistroi, codservico_secretaria, codsituacao, codmulher, aparecer) 
            VALUES (:datacomparecimento, :hrinicio, :hrtermino, :numregistro, :codservico_secretaria, :codsituacao, :codmulher, true)");
            $insere->bindValue(":datacomparecimento",$dtcomparecimento);
            $insere->bindValue(":hrinicio",$hrinicio);
            $insere->bindValue(":hrtermino",$hrtermino);
            $insere->bindValue(":numregistro",$selfuncionario);
            $insere->bindValue(":codservico_secretaria",$selservicosecretaria);
            $insere->bindValue(":codsituacao",$selsituacao);
            $insere->bindValue(":codmulher",$selmulher);
        
            $insere->execute();
            session_start();

            if($_SESSION['idAcessoUsuario'] == 4) {
                echo "<script>alert('Informe Cadastrado!')</script>";
                echo "<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/registraPresenca.php'>";
            } else {
                echo "<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/cadastros.php'>";
                echo "<script>alert('Informe Cadastrado!')</script>";
            }
           
        }

////////////////////////////////////////////////////EXCLUSÃO DA MULHER////////////////////////////////////////////////////////

 public function excluirMulher($codMulher) {
    $cmd = $this->pdo->prepare("UPDATE MULHER SET APARECER = FALSE WHERE CODMULHER = :codmulher;");

    //substituição
    $cmd->bindValue(":codmulher", $codMulher);

    //executando
    $cmd->execute();

}

////////////////////////////////////////////EXCLUSÃO DA NECESSIDADE ASSOCIADA A MULHER/////////////////////////////////////////
// public function excluirMulherNecessidade($codnecessidademulher) {
//     $cmd = $this->pdo->prepare("DELETE FROM NECESSIDADEMULHER WHERE CODNECESSIDADEMULHER = :codnecessidademulher");

//     //substituição
//     $cmd->bindValue(":codnecessidademulher", $codnecessidademulher);
//     //executando
//     $cmd->execute();

// }


////////////////////////////////////////////EXCLUSÃO DO FUNCIONARIO/////////////////////////////////////////
public function excluirFuncionario($numregistro) {
    $cmd = $this->pdo->prepare("UPDATE CADUSUARIO SET APARECER = FALSE WHERE NUMREGISTRO = :numregistro");

    //substituição
    $cmd->bindValue(":numregistro", $numregistro);
    echo"  <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/consultaFuncionario.php'>";
    

    //executando
    $cmd->execute();

}

////////////////////////////////////////////EXCLUSÃO DO FUNCIONARIO/////////////////////////////////////////
public function excluirLocal($codlocalcadastro) {

    $cmd = $this->pdo->prepare("UPDATE LOCALCADASTRO SET APARECER = FALSE WHERE CODLOCALCADASTRO = :codlocalcadastro");

    //substituição
    $cmd->bindValue(":codlocalcadastro", $codlocalcadastro);

    //executando
    $cmd->execute();
     echo"  <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/consultaLocal.php'>";

}

////////////////////////////////////////////EXCLUSÃO DE NECESSIDADES//////////////////////////////////////////////////////////
public function excluirNecessidade($codnecessidade) {
    $cmd = $this->pdo->prepare("UPDATE NECESSIDADE SET APARECER = FALSE WHERE CODNECESSIDADE = :codnecessidade");

    //substituição
    $cmd->bindValue(":codnecessidade", $codnecessidade);
    echo"  <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/consultaNecessidade.php'>";
    //executando
    $cmd->execute();

}

////////////////////////////////////////////EXCLUSÃO DE SERVIÇOS ASSOCIADOS A ALGUMA SECRETARIA/////////////////////////////////
// public function excluirServicoSecretaria($codservicosecretaria) {
//     $cmd = $this->pdo->prepare("DELETE FROM SERVICO_SECRETARIA WHERE CODSERVICO_SECRETARIA = :codservicosecretaria");

//     //substituição
//     $cmd->bindValue(":codservicosecretaria", $codservicosecretaria);
//     //executando
//     $cmd->execute();

// }

////////////////////////////////////////////EXCLUSÃO DE SERVIÇOS////////////////////////////////////////////////////////////////
public function excluirServico($codservico) {
    $cmd = $this->pdo->prepare("UPDATE SERVICO SET APARECER = FALSE WHERE CODSERVICO = :codservico");

    //substituição
    $cmd->bindValue(":codservico", $codservico);
    echo"  <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/consultaServico.php'>";

    //executando
    $cmd->execute();

}

////////////////////////////////////////////EXCLUSÃO DE SECRETARIAS////////////////////////////////////////////////////////////////
public function excluirSecretaria($codsecretaria) {
    $cmd = $this->pdo->prepare("UPDATE SERVICO_SECRETARIA SET APARECER = FALSE WHERE CODSECRETARIA_SS = :codsecretaria;
    UPDATE SECRETARIA SET APARECER = FALSE WHERE CODSECRETARIA = :codsecretaria");

    // -- DELETE FROM SERVICO_SECRETARIA WHERE CODSECRETARIA_SS = :codsecretaria;
    // DELETE FROM SECRETARIA WHERE CODSECRETARIA = :codsecretaria;");
    
    //substituição
    $cmd->bindValue(":codsecretaria", $codsecretaria);
    echo"  <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/consultaSecretaria.php'>";

    //executando
    $cmd->execute();

}

////////////////////////////////////////////EXCLUSÃO DO INFORME////////////////////////////////////////////////////////////////
public function excluirInforme($codinforme) {
    $cmd = $this->pdo->prepare("UPDATE INFORME SET APARECER = FALSE WHERE CODINFORME= :codinforme");

    //substituição
    $cmd->bindValue(":codinforme", $codinforme);
    echo"  <META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../view/consultaInforme.php'>";
    

    //executando
    $cmd->execute();

}

//////////////////////////////////////////////////ATUALIZANDO APENAS AS NECESSIDADES//////////////////////////////////////////////    
  
 //buscar os dados da necessidade especifica para atualizar
 public function buscarDadosNecessidade ($codnecessidade) {

    //caso o array estiver vazio:
    $res = array();
    
    $cmd = $this->pdo->prepare("SELECT * FROM NECESSIDADE WHERE CODNECESSIDADE = :codnecessidade");

    //substituicao dos dados
    $cmd->bindValue(":codnecessidade", $codnecessidade);
    $cmd->execute();

    //transformando em um array
    //fetch-> apenas uma pessoa
    $res = $cmd->fetch(PDO::FETCH_ASSOC);

    //retornando dados guardados na variiavel res
    return $res;

    }

    //ATUALIZANDO DADOS DA NECESSIDADE
    public function atualizarDadosNecessidade($codnecessidade,$necessidade)
    {
        $cmd = $this->pdo->prepare("UPDATE NECESSIDADE SET NECESSIDADE = :necessidade WHERE CODNECESSIDADE = :codnecessidade");
       
        $cmd->bindValue(":necessidade", $necessidade);
        $cmd->bindValue(":codnecessidade", $codnecessidade);
        $cmd->execute();
    }



/////////////////////////////////////////ATUALIZANDO A MULHER E AS NECESSIDADES ASSOCIADAS A ELA//////////////////////////////////////////////      
        //buscar os dados da mulher especifica para atualizar
        public function buscarDadosMulher ($codMulher) {

        //caso o array estiver vazio:
        $res = array();
        
        $cmd = $this->pdo->prepare("SELECT * FROM MULHER WHERE CODMULHER = :codmulher ");

        //substituicao dos dados
        $cmd->bindValue(":codmulher", $codMulher);
        $cmd->execute();

        //transformando em um array
        //fetch-> apenas uma pessoa
        $res = $cmd->fetch(PDO::FETCH_ASSOC);

        //retornando dados guardados na variiavel res
        return $res;

        }

        //buscando dados da tabela necessidademulher para atualização:
        // public function buscarDadosNecessidadeM ($codnecessidademulher) {

        //     //caso o array estiver vazio:
        //     $res = array();
            
        //     $cmd = $this->pdo->prepare("SELECT * FROM NECESSIDADEMULHER WHERE CODNECESSIDADEMULHER = :codnecessidademulher");
    
        //     //substituicao dos dados
        //     $cmd->bindValue(":codnecessidademulher", $codnecessidademulher);
        //     $cmd->execute();
    
        //     //transformando em um array
        //     //fetch-> apenas uma pessoa
        //     $res = $cmd->fetch(PDO::FETCH_ASSOC);
    
        //     //retornando dados guardados na variiavel res
        //     return $res;
    
        //     }
    

        //Atualizar os dados do banco (Mulher e as Necessidades Associada a ela)
        public function atualizarDadosMulher ($codMulher,$nomeMulher,$bairro,$emailMulher,$celular,$telefone,$dataNasc,$local,$funcionario) {
        $cmd = $this->pdo->prepare("UPDATE MULHER SET NOME = :nome, BAIRRO = :bairro, EMAIL = :email, CEL = :cel, TEL = :tel, DTNASC = :dtnasc, CODLOCALCADASTRO = :localcadastro, NUMREGISTROM = :numregistro WHERE CODMULHER = :codmulher ");
    
        //substituicao
        $cmd->bindValue(":nome",$nomeMulher);
        $cmd->bindValue(":bairro",$bairro);
        $cmd->bindValue(":email",$emailMulher);
        $cmd->bindValue(":cel",$celular);
        $cmd->bindValue(":tel",$telefone);
        $cmd->bindValue(":dtnasc",$dataNasc);
        $cmd->bindValue(":localcadastro",$local);
        $cmd->bindValue(":numregistro",$funcionario);
        $cmd->bindValue(":codmulher", $codMulher);
        $cmd->execute();
        

        //ATUALIZANDO (CADASTRANDO NOVOS SERVIÇOS ASSOCIADOS A MULHER) TABELA NECESSIDADEMULHER
        // foreach($necessidadesSelecionadas as $CODNECESSIDADE){
        // $cmd = $this->pdo->prepare("INSERT INTO NECESSIDADEMULHER (CODMULHER_N, CODNECESSIDADE)values(:codmulher, :codnecessidade)");

        // //substituição
        // $cmd->bindValue(":codmulher", $codMulher);
        // $cmd->bindValue(":codnecessidade",$CODNECESSIDADE);

        // //executa
        // $cmd->execute();   
        // }

      }

//////////////////////////////////////////////////////////ATUALIZANDO FUNCIONARIOS//////////////////////////////////////////////

      //buscar os dados do funcionario especifico para atualizar
      public function buscarDadosFuncionario ($NumRegistro) {

        //caso o array estiver vazio:
        $res = array();
        
        $cmd = $this->pdo->prepare("SELECT * FROM CADUSUARIO WHERE NUMREGISTRO = :numregistro");

        //substituicao dos dados
        $cmd->bindValue(":numregistro", $NumRegistro);
        $cmd->execute();

        //transformando em um array
        //fetch-> apenas uma pessoa
        $res = $cmd->fetch(PDO::FETCH_ASSOC);

        //retornando dados guardados na variiavel res
        return $res;

        }
        
        //ATUALIZANDO DADOS DO FUNCIONARIO
        public function atualizarDadosFuncionario($NumRegistro,$CodNivel,$NomeFuncionario,$Email,$Senha)
        {
            $cmd = $this->pdo->prepare("UPDATE CADUSUARIO SET NIVEL_ACESSO = :nivel_acesso, NOME_FUNCIONARIO = :nome_funcionario, EMAIL_FUNCIONARIO = :email_funcionario, SENHA = :senha WHERE NUMREGISTRO = :numregistro");
            $cmd->bindValue(":nivel_acesso", $CodNivel);
            $cmd->bindValue(":nome_funcionario", $NomeFuncionario);
            $cmd->bindValue(":email_funcionario", $Email);
            $cmd->bindValue(":senha", $Senha);
            $cmd->bindValue(":numregistro", $NumRegistro);
            if($CodNivel == 'adm'){
                $cmd->bindValue(":nivel_acesso",'1');
            }
            else if($CodNivel == 'mod'){
                $cmd->bindValue(":nivel_acesso", '2');
            }
            else if($CodNivel == 'func'){
                $cmd->bindValue(":nivel_acesso", '3');
            }
            else if($CodNivel == 'info'){
                $cmd->bindValue(":nivel_acesso", '4');
            }
            $cmd->execute();
    
        }
 //////////////////////////////////////////////////////////ATUALIZANDO LOCAL////////////////////////////////////////////////////

         //buscar os dados do local especifico para atualizar
        public function buscarDadosLocal ($codlocalcadastro) {

        //caso o array estiver vazio:
        $res = array();
        
        $cmd = $this->pdo->prepare("SELECT * FROM LOCALCADASTRO WHERE CODLOCALCADASTRO = :codlocalcadastro");

        //substituicao dos dados
        $cmd->bindValue(":codlocalcadastro", $codlocalcadastro);
        $cmd->execute();

        //transformando em um array
        //fetch-> apenas uma pessoa
        $res = $cmd->fetch(PDO::FETCH_ASSOC);

        //retornando dados guardados na variavel res
        return $res;

        }

        public function atualizaDadosLocal($codlocalcadastro, $nomelocal)
        {
            $cmd = $this->pdo->prepare("UPDATE LOCALCADASTRO SET NOMELOCAL = :nomelocal WHERE CODLOCALCADASTRO = :codlocalcadastro");
    
            //SUBSTITUIÇÃO
            $cmd->bindValue(":nomelocal",$nomelocal);
            $cmd->bindValue(":codlocalcadastro",$codlocalcadastro);
            $cmd->execute();
        }

/////////////////////////////////////////////ATUALIZANDO SERVIÇOS ASSOCIADOS A SECRETERIA E A SECRETARIA///////////////////////////////

         //buscar os dados do serviço associado a secretaria para atualizar
         public function buscarDadosServicoSecretaria ($codservicosecretaria) {

            //caso o array estiver vazio:
            $res = array();
            
            $cmd = $this->pdo->prepare("SELECT * FROM SERVICO_SECRETARIA WHERE CODSERVICO_SECRETARIA = :codservicosecretaria");
    
            //substituicao dos dados
            $cmd->bindValue(":codservicosecretaria", $codservicosecretaria);
            $cmd->execute();
    
            //transformando em um array
            //fetch-> apenas uma pessoa
            $res = $cmd->fetch(PDO::FETCH_ASSOC);
    
            //retornando dados guardados na variiavel res
            return $res;
    
            }

         //buscar os dados da secretaria
         public function buscarDadosSecretaria ($codsecretaria) {

            //caso o array estiver vazio:
            $res = array();
            $cmd = $this->pdo->prepare("SELECT * FROM SECRETARIA WHERE CODSECRETARIA = :codsecretaria");
    
            //substituicao dos dados
            $cmd->bindValue(":codsecretaria", $codsecretaria);
            $cmd->execute();
    
            //transformando em um array
            //fetch-> apenas um registro
            $res = $cmd->fetch(PDO::FETCH_ASSOC);
    
            //retornando dados guardados na variiavel res
            return $res;
            }

            //Atualizar os dados do banco (Serviço já associado e secretaria)
            



  public function atualizarDadosSecretaria ($codsecretaria, $nomeSecretaria, $servicosSelecionados) 
  {
      $cmd = $this->pdo->prepare("UPDATE SECRETARIA SET NOMESECRETARIA = :nomesecretaria WHERE CODSECRETARIA = :codsecretaria");
      
      //substituicao
      $cmd->bindValue(":nomesecretaria", $nomeSecretaria);
      $cmd->bindValue(":codsecretaria", $codsecretaria);
      $cmd->execute();

      foreach($servicosSelecionados as $codservico) 
      {
          $teste = $this->pdo->prepare("SELECT * FROM SERVICO_SECRETARIA WHERE CODSECRETARIA_SS = :codsecretaria AND CODSERVICO = :codservico");
          $teste->bindValue(":codsecretaria", $codsecretaria);
          $teste->bindValue(":codservico",$codservico);
          $teste->execute();
          
          if($teste->rowCount()>0)
          {
            echo "<script>alert('O serviço já existe nessa secretaria!')</script>";
          }
          else
          {
              $cmd = $this->pdo->prepare("INSERT INTO SERVICO_SECRETARIA (CODSERVICO, CODSECRETARIA_SS) values (:codservico, :codsecretaria)");
              $cmd->bindValue(":codservico",$codservico);
              $cmd->bindValue(":codsecretaria",$codsecretaria);
              $cmd->execute();
              echo "<script>alert('Atualizado com sucesso!')</script>";
          }
      }
  }



                            /////////////////////// ATUALIZANDO O SERVIÇO///////////////////////////////

        //buscar os dados do serviço para atualizar
        public function buscarDadosServico ($codservico) {

            //caso o array estiver vazio:
            $res = array();
            
            $cmd = $this->pdo->prepare("SELECT * FROM SERVICO WHERE CODSERVICO = :codservico");
    
            //substituicao dos dados
            $cmd->bindValue(":codservico", $codservico);
            $cmd->execute();
    
            //transformando em um array
            //fetch-> apenas uma pessoa
            $res = $cmd->fetch(PDO::FETCH_ASSOC);
    
            //retornando dados guardados na variiavel res
            return $res;
    
            }


           public function atualizarDadosServico ($codservico, $nomeservico, $objetivo)
            {
   
           $cmd = $this->pdo->prepare("UPDATE SERVICO SET NOMESERVICO = :nomeservico, OBJETIVO = :objetivo  WHERE CODSERVICO = :codservico");    
   
           //substituição dos dados
           $cmd->bindValue(":nomeservico", $nomeservico);
           $cmd->bindValue(":objetivo", $objetivo);
           $cmd->bindValue(":codservico", $codservico);
           $cmd->execute();
   
           }

                     ///////////////////////ATUALIZANDO O INFORME ///////////////////////////////
         

     //buscar os dados do informe especifico para atualizar
     public function buscarDadosInforme ($codinforme) {

        //caso o array estiver vazio:
        $res = array();
        
        $cmd = $this->pdo->prepare("SELECT * FROM INFORME WHERE CODINFORME = :codinforme");

        //substituicao dos dados
        $cmd->bindValue(":codinforme", $codinforme);
        $cmd->execute();

        //transformando em um array
        //fetch-> apenas uma pessoa
        $res = $cmd->fetch(PDO::FETCH_ASSOC);

        //retornando dados guardados na variiavel res
        return $res;

        }

        public function atualizaDadosInforme ($codinforme, $dtcomparecimento, $hrinicio, $hrtermino, $NumRegistro, $codservicosecretaria_i, $codsituacao, $codmulher)
         {

        $cmd = $this->pdo->prepare("UPDATE INFORME SET DATACOMPARECIMENTO = :dtcomparecimento, HRINICIO = :hrinicio, HRTERMINO = :hrtermino, NUMREGISTROI = :numregistro, CODSERVICO_SECRETARIA = :codservico_secretaria, CODSITUACAO = :codsituacao, CODMULHER = :codmulher WHERE CODINFORME = :codinforme");    

        //substituição dos dados
        $cmd->bindValue(":dtcomparecimento", $dtcomparecimento);
        $cmd->bindValue(":hrinicio", $hrinicio);
        $cmd->bindValue(":hrtermino", $hrtermino);
        $cmd->bindValue(":numregistro", $NumRegistro);
        $cmd->bindValue(":codservico_secretaria", $codservicosecretaria_i);
        $cmd->bindValue(":codsituacao", $codsituacao);
        $cmd->bindValue(":codmulher", $codmulher);
        $cmd->bindValue(":codinforme", $codinforme);
        $cmd->execute();

         }
    /* 
        ESSE CODIGO VALIDA CERTINHO A SENHA CRIPTGRAFADA, MAS PARA CADASTRAR 
        UMA SENHA JA CRIPTOGRAFADA É PRECISO TER UM CADASTRO E TER FEITO UM LOGIN, 
        PORTANDO DE PRIMEIRO MOMENTO DEIXE ESSE CODIGO PRIMEIRO LOGIN COMENTADO, FAÇA UM INSERT DIRETO NO BANCO
        ENTRE NO SITE, E CADASTRE OUTROS USUARIOS
        DEPOIS DISSO PODE RODAR ELE E COMENTAR O OUTRO ABAIXO, QUE VALIDA SEM A SENHA CRIPTOGRAFADA
        (SE NAO FIZER ISSO ELE VAI SEMPRE COMPARAR COM UMA SENHA QUE NAO TEM CRIPTOGRAFIA E CAIR
        NO ELSE)     
*/



        public function Login($email, $senha)
          { 
            $validaLogin = $this->pdo->prepare("select numregistro,nivel_acesso, senha from cadusuario where email_funcionario = :e");
            $validaLogin->bindValue(":e",$email);
            $validaLogin->execute();
            
            //verifica se foi retornado algum dado
            if ($validaLogin->rowCount()>0) 
            {
                $login = $validaLogin->fetch();
                
                //compara se a senha descriptografada é igual a criptografada 
                if (password_verify($senha, $login['senha'])) 
                {
                    //se sim inicia a sessão
                    session_start();
                    $_SESSION['idAcesso'] = $login['numregistro'];

                    //atribui o nivel de acesso a outra variavel
                    $_SESSION['idAcessoUsuario']  = $login['nivel_acesso'];
                    return true;

                } 
                else 
                {
                    ?>
                        <link rel="stylesheet" href="../view/css/alert.css">
                        <div class="failed-login">Login ou senha inválidos!</div>
                    <?php
                    return false;
                }
            } else {
                ?>
                    <link rel="stylesheet" href="../view/css/alert.css">
                    <div class="failed-login">Login ou senha inválidos!</div>
                <?php
                return false;
            }            
        }

/*

public function Login ($email, $senha) {

    $validaLogin= $this->pdo->prepare ("select numregistro from cadusuario where email_funcionario = :e AND senha = :s");
    
    $validaLogin->bindValue(":e", $email);
    $validaLogin->bindValue(":s", $senha);
    $validaLogin->execute();
    
    if ($validaLogin->rowCount()>0)
    {
        $login = $validaLogin->fetch();
        session_start();
    
        $_SESSION['idAcesso'] = $login ['numregistro'];
    
        return true;
    }
    
    else {
        
        header('location: ../controller/validaLogin.php');

        return false;
    }
    
    
    
    }

*/


    }
?>